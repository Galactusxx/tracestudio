"""Build self-contained UI preview and source-only ZIP. No investigation data included."""
from pathlib import Path
import zipfile,hashlib,json
ROOT=Path(__file__).resolve().parent
html=(ROOT/'static/index.html').read_text()
html=html.replace('<html lang="en">','<html lang="en" data-preview="true">')
html=html.replace('<link rel="stylesheet" href="/style.css">','<style>'+(ROOT/'static/style.css').read_text()+'</style>')
html=html.replace('<script src="/app.js" defer></script>','')
html=html.replace('v0.2 / DEVELOPMENT BUILD','v0.2 / INTERFACE PREVIEW')
html=html.replace('Mainnet · ETH gas · No end-user RPC configuration required','Preview only · Start the included server for live data')
html=html.replace('</body>','<script>'+(ROOT/'static/app.js').read_text()+'</script></body>')
(ROOT/'trace-preview.html').write_text(html)
allowed={'.py','.js','.cjs','.css','.html','.sql','.md','.sh','.yaml','.yml','.txt'}
files=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and (p.suffix in allowed or p.name in {'.gitignore','.dockerignore','Dockerfile','Caddyfile','env.example','RELEASE-GATES.json'})]
archive=ROOT.parent/'trace-studio-v0.2.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(files): z.write(p,'robinhood-forensics/'+str(p.relative_to(ROOT)))
    manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
    z.writestr('robinhood-forensics/MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert not any('.sqlite3' in n or '__pycache__' in n for n in z.namelist())
print(f'Built {archive.name}: {archive.stat().st_size} bytes, {len(files)} source/preview files + manifest')
