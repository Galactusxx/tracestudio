"""Synthetic test data only; never loaded by the application or presented as chain findings."""
import unittest,tempfile
from app.core import *
from app.pipeline import run
from app.sources import Client,SourceError
from tests.test_detectors import A,B,F,T,X,event
class PipelineClient(Client):
    def rpc(self,m,p):
        self.calls+=1
        if m=='eth_chainId': result='0x1237'
        elif m=='eth_getBlockByNumber': result={'number':'0x100','hash':'0x'+'a'*64,'timestamp':'0x65000000'}
        elif m=='eth_getCode': result='0x6000' if p[0]==T else '0x'
        elif m=='eth_getTransactionReceipt': result=None
        elif m=='eth_call':
            d=p[0]['data'][:10]
            if d=='0x01ffc9a7': raise SourceError('Not supported')
            if d in ('0x95d89b41','0x06fdde03'): result='0x'+b'SYNTHETIC TEST ONLY'.ljust(32,b'\0').hex()
            else: result='0x'+hex(18 if d=='0x313ce567' else 1000000)[2:].zfill(64)
        else: raise AssertionError(m)
        self.last_raw=self.store.raw(self.job,'test-fixture',m,result); return result
    def get(self,path,params=None):
        self.calls+=1
        if path=='/tokens/'+T: result={'holders_count':'2'}
        elif path=='/addresses/'+T: result={'creator_address_hash':F,'creation_transaction_hash':'0x'+'f'*64}
        elif path.endswith('/holders'): result={'items':[{'address':{'hash':A},'value':'100'},{'address':{'hash':B},'value':'100'}],'next_page_params':None}
        elif path.endswith('/transfers'):
            es=[event(1,F,A),event(2,F,B),event(3,A,X),event(4,B,X),event(5,A,X),event(6,B,X)]
            result={'items':[{'transaction_hash':e['tx_hash'],'block_number':e['block_number'],'log_index':e['log_index'],'from':{'hash':e['from_address']},'to':{'hash':e['to_address']},'token':{'address_hash':T,'type':'ERC-20','decimals':'18'},'total':{'value':e['amount_raw']},'timestamp':e['timestamp']} for e in es],'next_page_params':None}
        else: result={'items':[],'next_page_params':None}
        self.last_raw=self.store.raw(self.job,'test-fixture',path,result); return result
class PipelineTests(unittest.TestCase):
    def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.s=Store(self.tmp.name+'/db'); self.j=self.s.create_job(T)
    def tearDown(self): self.tmp.cleanup()
    def test_end_to_end(self):
        run(self.s,self.j,PipelineClient); j=self.s.job(self.j)
        self.assertEqual(j['status'],'partial',j.get('error')); r=j['report']
        self.assertEqual(r['chain_id'],4663); self.assertTrue(r['coverage']['snapshot_consistent']); self.assertEqual(len(r['events']),6)
        self.assertGreater(len(r['token_convergence']),0); self.assertIsNone(r['summary']['estimated_proceeds_usd'])
        evidence={e['id'] for e in r['events']}
        for f in r['token_convergence']: self.assertTrue(set(f['evidence'])<=evidence)
        self.assertGreater(len(self.s.rows('SELECT * FROM raw_responses')),0)
    def test_wrong_chain_has_no_report(self):
        class Wrong(PipelineClient):
            def rpc(self,m,p): return '0x1' if m=='eth_chainId' else super().rpc(m,p)
        run(self.s,self.j,Wrong); j=self.s.job(self.j); self.assertEqual(j['status'],'failed'); self.assertIsNone(j['report']); self.assertIn('Wrong network',j['error'])
    def test_outage_has_no_findings(self):
        class Offline(PipelineClient):
            def rpc(self,m,p): raise SourceError('Cannot reach RPC')
        run(self.s,self.j,Offline); self.assertIsNone(self.s.job(self.j)['report']); self.assertEqual(self.s.rows('SELECT * FROM findings'),[])
    def test_reorg_blocks_report(self):
        class Reorg(PipelineClient):
            def rpc(self,m,p):
                r=super().rpc(m,p)
                if m=='eth_getBlockByNumber' and p[0]=='0x100': r['hash']='0x'+'b'*64
                return r
        run(self.s,self.j,Reorg); self.assertEqual(self.s.job(self.j)['status'],'failed'); self.assertIsNone(self.s.job(self.j)['report'])
if __name__=='__main__': unittest.main()
