import unittest
from app.enrichment import *
from tests.test_detectors import A,B,F,T,U,P,event
class AccountingTests(unittest.TestCase):
 def test_peak(self):
  es=[event(1,F,A,T,'100'),event(2,A,B,T,'40')];h=holder_history(A,T,es,'60',18);self.assertEqual(h['event_reconstructed_peak_raw'],'100');self.assertEqual(h['opening_balance_raw'],'0')
 def test_missing_balance(self):self.assertFalse(holder_history(A,T,[],None,18)['available'])
 def test_reconciliation_failure(self):self.assertFalse(holder_history(A,T,[event(1,F,A,T,'100')],'50',18)['available'])
 def test_fifo(self):
  a=event(1,F,A,T,'100');b=event(11,A,P,T,'50');r=fifo_age(A,T,[a,b],[{'wallet':A,'tx_hash':b['tx_hash']}],'0');self.assertEqual(r['mean_known_lot_holding_seconds'],'10.0')
 def test_unknown_initial_lots(self):
  b=event(11,A,P,T,'50');r=fifo_age(A,T,[b],[{'wallet':A,'tx_hash':b['tx_hash']}],'100');self.assertIsNone(r['mean_known_lot_holding_seconds'])
 def test_mixed_bounds(self):
  a=event(1,F,A,U,'100');b=event(2,A,B,U,'50');r=attribution_bounds([a,b],{a['id']},{(F,U):100,(A,U):100,(B,U):0},{F,A,B});self.assertEqual(r['events'][1]['minimum_raw'],'0');self.assertEqual(r['events'][1]['maximum_raw'],'50')
 def test_incomplete_bounds(self):self.assertFalse(attribution_bounds([event(1,A,B)],set(),{},set())['available'])
class PriceTests(unittest.TestCase):
 def payload(self,rows):return {'meta':{'base':{'address':T},'quote':{'address':U}},'data':{'attributes':{'ohlcv_list':rows}}}
 def test_no_lookahead(self):
  p=self.payload([[120,2,3,1,2,100],[60,1,2,1,1,100]]);self.assertEqual(candle_quote(p,T,150)['candle_start'],60)
 def test_stale(self):self.assertIsNone(candle_quote(self.payload([[0,1,1,1,1,1]]),T,1000))
 def test_wrong_asset(self):self.assertIsNone(candle_quote(self.payload([[0,1,1,1,1,1]]),A,70))
 def test_invalid_candle(self):self.assertIsNone(candle_quote(self.payload([[0,-1,1,-1,0,1]]),T,70))
class PoolTests(unittest.TestCase):
 def test_factory_membership(self):
  class C:
   last_raw='test'
   def rpc(self,m,p):
    if m=='eth_getCode':return '0x6000'
    sig=p[0]['data'][:10]
    value={selector('factory()'):V3_FACTORY,selector('token0()'):T,selector('token1()'):U,selector('fee()'):3000,selector('getPool(address,address,uint24)'):P}[sig]
    return '0x'+(hex(value)[2:] if isinstance(value,int) else value[2:]).zfill(64)
  self.assertEqual(verify_pool(C(),P,10)['factory'],V3_FACTORY)
 def test_untrusted_factory(self):
  class C:
   last_raw='test'
   def rpc(self,m,p):return '0x'+F[2:].zfill(64)
  self.assertIsNone(verify_pool(C(),P,10))
 def test_swap_delta_mismatch(self):
  e=event(1,A,P,T,'100');sale={'tx_hash':e['tx_hash'],'pools':[P]};self.assertFalse(verify_swap_deltas(sale,[e],{'logs':[]},{P:{'token0':T,'token1':U}}))
class ReceiptTests(unittest.TestCase):
 def fixture(self):
  outgoing=event(1,P,A,U,'100');incoming=event(2,A,P,T,'200')
  outgoing.update(tx_hash='0x'+'f'*64,log_index=1);incoming.update(tx_hash=outgoing['tx_hash'],log_index=2)
  def transfer(e):return {'address':e['asset'],'topics':['0x'+keccak(b'Transfer(address,address,uint256)'),'0x'+e['from_address'][2:].zfill(64),'0x'+e['to_address'][2:].zfill(64)],'data':'0x'+hex(int(e['amount_raw']))[2:].zfill(64),'logIndex':hex(e['log_index'])}
  data=''.join(hex(n%(1<<256))[2:].zfill(64) for n in (200,-100,0,0,0))
  swap={'address':P,'topics':['0x'+keccak(b'Swap(address,address,int256,int256,uint160,uint128,int24)')],'data':'0x'+data}
  return {'tx_hash':incoming['tx_hash'],'pools':[P]},[outgoing,incoming],{'status':'0x1','logs':[transfer(outgoing),transfer(incoming),swap]},{P:{'token0':T,'token1':U}}
 def test_callback_order(self):self.assertTrue(verify_swap_deltas(*self.fixture()))
 def test_spoofed_transfer_rejected(self):
  sale,es,r,p=self.fixture();es[1]['amount_raw']='201';self.assertFalse(verify_swap_deltas(sale,es,r,p))
 def test_spoofed_delta_rejected(self):
  sale,es,r,p=self.fixture();r['logs'][-1]['data']='0x'+hex(201)[2:].zfill(64)+r['logs'][-1]['data'][66:];self.assertFalse(verify_swap_deltas(sale,es,r,p))
if __name__=='__main__':unittest.main()
