"""Isolated local HTTPS QA server. SYNTHETIC FIXTURES ONLY; not production."""
import sys,tempfile,threading,ssl,datetime,ipaddress,secrets
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import serialization,hashes
from cryptography.hazmat.primitives.asymmetric import rsa
from wsgiref.simple_server import make_server
from app.core import Store
from app.hardened import create_app,create_user,work_once
from app.pipeline import run
from tests.test_pipeline import PipelineClient
with tempfile.TemporaryDirectory() as d:
 p=Path(d);key=rsa.generate_private_key(public_exponent=65537,key_size=2048);name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'localhost')]);now=datetime.datetime.now(datetime.timezone.utc)
 cert=x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-datetime.timedelta(minutes=1)).not_valid_after(now+datetime.timedelta(days=1)).add_extension(x509.SubjectAlternativeName([x509.DNSName('localhost'),x509.IPAddress(ipaddress.ip_address('127.0.0.1'))]),False).sign(key,hashes.SHA256())
 (p/'key.pem').write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.TraditionalOpenSSL,serialization.NoEncryption()));(p/'cert.pem').write_bytes(cert.public_bytes(serialization.Encoding.PEM))
 s=Store(str(p/'qa.db'));create_user(s,'qa-operator','synthetic UI test password only')
 def worker():
  import time
  while True:
   if not work_once(s,'qa-worker',lambda s,j:run(s,j,PipelineClient)):time.sleep(.1)
 threading.Thread(target=worker,daemon=True).start()
 app=create_app(s,production=True,hosts={'127.0.0.1','localhost'});server=make_server('127.0.0.1',8083,app);ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.load_cert_chain(p/'cert.pem',p/'key.pem');server.socket=ctx.wrap_socket(server.socket,server_side=True)
 print('Synthetic HTTPS QA server listening on localhost:8083',flush=True);server.serve_forever()
