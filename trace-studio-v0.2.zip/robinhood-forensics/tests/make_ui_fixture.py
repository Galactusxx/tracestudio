"""Generate isolated synthetic UI QA fixture. Never called by the running app."""
import json,os,sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from app.core import Store
from app.pipeline import run
from tests.test_pipeline import PipelineClient,T
out=Path(os.environ.get('QA_DIR','/data/qa')); out.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory() as d:
    s=Store(d+'/fixture.db'); j=s.create_job(T); run(s,j,PipelineClient)
    (out/'fixture.json').write_text(json.dumps(s.job(j)))
print('Synthetic fixture written to',out/'fixture.json')
