import unittest,tempfile
from app.core import *
from app.sources import discover, SourceError
A='0x'+'1'*40
class Fake:
    def __init__(self,s,j,chain='0x1237',code='0x6000',nft=False): self.store=s; self.job=j; self.last_raw=None; self.chain=chain; self.code=code; self.nft=nft
    def rpc(self,m,p):
        if m=='eth_chainId': return self.chain
        if m=='eth_getBlockByNumber': return {'number':'0x100','hash':'0x'+'a'*64,'timestamp':'0x65000000'}
        if m=='eth_getCode': return self.code
        if m=='eth_call':
            d=p[0]['data'][:10]
            if d=='0x01ffc9a7': raise SourceError('unsupported') if not self.nft else ValueError('nft')
            if d in ('0x95d89b41','0x06fdde03'): return '0x'+b'TEST'.ljust(32,b'\0').hex()
            return '0x'+hex(18 if d=='0x313ce567' else 100)[2:].zfill(64)
class DiscoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.s=Store(self.tmp.name+'/db'); self.j=self.s.create_job(A)
    def tearDown(self): self.tmp.cleanup()
    def test_keccak(self): self.assertEqual(keccak(b''),'c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470')
    def test_address(self):
        self.assertEqual(address('0x52908400098527886E0F7030069857D2E4169EE7'),'0x52908400098527886e0f7030069857d2e4169ee7')
        self.assertEqual(address('0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed'),'0x5aaeb6053f3e94c9b9a09f33669435e7ef1beaed')
        for bad in ['0x1234',ZERO,'0x5aaeb6053F3E94C9b9A09f33669435E7Ef1BeAed']:
            with self.assertRaises(ValueError): address(bad)
    def test_units_exact(self): self.assertEqual(units(10**30+1,18),'1000000000000.000000000000000001')
    def test_discovery(self):
        m=discover(Fake(self.s,self.j),A); self.assertEqual(m['symbol'],'TEST'); self.assertEqual(m['snapshot_block'],256)
    def test_wrong_chain(self):
        with self.assertRaises(SourceError): discover(Fake(self.s,self.j,chain='0x1'),A)
    def test_no_contract(self):
        with self.assertRaises(ValueError): discover(Fake(self.s,self.j,code='0x'),A)
if __name__=='__main__': unittest.main()
