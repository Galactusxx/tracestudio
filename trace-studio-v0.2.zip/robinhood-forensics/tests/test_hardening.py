import unittest,tempfile,io,json
from app.core import Store,Cancelled,LeaseLost
from app.hardened import create_user,login,create_app,enqueue,cancel,claim,work_once,password_hash
from app.sources import Client
from app.pipeline import run
from tests.test_pipeline import PipelineClient,T
class SecurityTests(unittest.TestCase):
 @classmethod
 def setUpClass(c):
  c.tmp=tempfile.TemporaryDirectory();c.s=Store(c.tmp.name+'/db');c.a=create_user(c.s,'alice','correct horse battery staple');c.b=create_user(c.s,'bob','different horse battery staple');c.ta,c.ua=login(c.s,'alice','correct horse battery staple');c.tb,c.ub=login(c.s,'bob','different horse battery staple')
 @classmethod
 def tearDownClass(c):c.tmp.cleanup()
 def req(self,path,method='GET',body=None,token=None,csrf=None,host='trace.test',origin=None):
  raw=json.dumps(body or {}).encode();e={'HTTP_HOST':host,'PATH_INFO':path,'REQUEST_METHOD':method,'CONTENT_TYPE':'application/json','CONTENT_LENGTH':str(len(raw)),'wsgi.input':io.BytesIO(raw),'REMOTE_ADDR':'127.0.0.1'}
  if token:e['HTTP_COOKIE']='trace_session='+token
  if csrf:e['HTTP_X_CSRF_TOKEN']=csrf
  if origin:e['HTTP_ORIGIN']=origin
  result=[];hs=[];data=b''.join(create_app(self.s,True,{'trace.test'})(e,lambda st,h:(result.append(int(st[:3])),hs.extend(h))));return result[0],json.loads(data),dict(hs)
 def test_auth_required(self):self.assertEqual(self.req('/api/jobs')[0],401)
 def test_host(self):self.assertEqual(self.req('/api/jobs',host='evil.test')[0],403)
 def test_csrf_and_origin(self):
  self.assertEqual(self.req('/api/investigations','POST',{'address':T},self.ta,'bad')[0],403)
  self.assertEqual(self.req('/api/investigations','POST',{'address':T},self.ta,self.ua['csrf'],origin='https://evil.test')[0],403)
 def test_job_isolation_all_subresources(self):
  j=enqueue(self.s,self.a,T,'same');self.assertEqual(j,enqueue(self.s,self.a,T,'same'))
  for suffix in ('','/events','/export','/evidence/'+'a'*64):self.assertEqual(self.req('/api/jobs/'+j+suffix,token=self.tb)[0],404)
  self.assertEqual(self.req('/api/jobs/'+j,token=self.ta)[0],200);cancel(self.s,self.a,j)
 def test_secure_cookie(self):
  st,_,h=self.req('/api/login','POST',{'username':'alice','password':'correct horse battery staple'});self.assertEqual(st,200)
  for flag in ('HttpOnly','Secure','SameSite=Strict'):self.assertIn(flag,h['Set-Cookie'])
 def test_wrong_password(self):self.assertEqual(self.req('/api/login','POST',{'username':'alice','password':'wrong but sufficiently long'})[0],401)
 def test_csp(self):self.assertIn("frame-ancestors 'none'",self.req('/api/session',token=self.ta)[2]['Content-Security-Policy'])
class WorkerTests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.s=Store(self.tmp.name+'/db')
 def tearDown(self):self.tmp.cleanup()
 def test_exclusive_claim(self):
  j=enqueue(self.s,'u',T);self.assertEqual(claim(self.s,'w1'),j);self.assertIsNone(claim(self.s,'w2'))
 def test_stale_worker_fenced(self):
  j=enqueue(self.s,'u',T);claim(self.s,'w1',-1);self.assertEqual(claim(self.s,'w2'),j);s=Store(self.s.path);s.lease_job=j;s.lease_owner='w1'
  with self.assertRaises(LeaseLost):s.update(j,stage='stale')
 def test_cancelled_worker_fenced(self):
  j=enqueue(self.s,'u',T);claim(self.s,'w');cancel(self.s,'u',j);s=Store(self.s.path);s.lease_job=j;s.lease_owner='w'
  with self.assertRaises(Cancelled):s.update(j,stage='wrong')
 def test_worker_pipeline(self):
  j=enqueue(self.s,'u',T);work_once(self.s,'w',lambda s,j:run(s,j,PipelineClient));self.assertEqual(self.s.job(j)['status'],'partial');self.assertIsNone(self.s.job(j)['lease_owner'])
 def test_cancel_queued(self):
  j=enqueue(self.s,'u',T);cancel(self.s,'u',j);self.assertIsNone(claim(self.s,'w'))
 def test_cached_page_replay(self):
  j=self.s.create_job(T);c=Client(self.s,j);calls=[]
  def get(path,q):
   calls.append(1);d={'items':[{'ok':True}],'next_page_params':None};c.last_raw=self.s.raw(j,'test',path,d);return d
  c.get=get;self.assertEqual(list(c.pages('/test'))[0][0],[{'ok':True}]);self.assertEqual(list(c.pages('/test'))[0][0],[{'ok':True}]);self.assertEqual(len(calls),1)
if __name__=='__main__':unittest.main()
