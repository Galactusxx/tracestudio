import unittest
from app.core import ZERO
from app.detectors import *
A='0x'+'1'*40; B='0x'+'2'*40; C='0x'+'3'*40; X='0x'+'4'*40; Y='0x'+'5'*40; F='0x'+'6'*40; T='0x'+'7'*40; U='0x'+'8'*40; P='0x'+'9'*40

def event(n,f,t,asset=T,amount='100',block=None,tx=None):
    return {'id':f'e{n}','from_address':f,'to_address':t,'asset':asset,'amount_raw':amount,'decimals':18,'block_number':block if block is not None else n,'block_hash':None,'tx_index':0,'log_index':n,'tx_hash':tx or '0x'+hex(n)[2:].zfill(64),'timestamp':f'2026-01-01T00:{n//60:02}:{n%60:02}Z','kind':'transfer','raw_id':'test'}
class GraphTests(unittest.TestCase):
    def test_edges_evidence(self):
        g=graph([event(1,A,B),event(2,B,C)])
        self.assertEqual(len(g['nodes']),3); self.assertEqual(g['edges'][0]['event_id'],'e1')
class RelationshipTests(unittest.TestCase):
    def test_router_alone_not_relationship(self):
        es=[event(1,A,P),event(2,B,P),event(3,A,P),event(4,B,P)]
        self.assertEqual(relationships(es,[A,B],{P:'router'})[0],[])
    def test_funder_alone_not_relationship(self):
        es=[event(1,F,A,'native:4663'),event(2,F,B,'native:4663')]
        self.assertEqual(relationships(es,[A,B],{})[0],[])
    def test_multiple_families(self):
        es=[event(1,F,A,'native:4663'),event(2,F,B,'native:4663'),event(3,A,X),event(4,A,X),event(5,B,X),event(6,B,X)]
        links,clusters,_=relationships(es,[A,B],{})
        self.assertEqual(len(links),1); self.assertEqual(links[0]['score'],65); self.assertEqual(len(clusters),1)
class SaleTests(unittest.TestCase):
    def receipt(self,es):
        logs=[{'address':P,'topics':[next(iter(SWAPS))]}]
        for e in es: logs.append({'address':e['asset'],'topics':[TRANSFER,'0x'+e['from_address'][2:].zfill(64),'0x'+e['to_address'][2:].zfill(64)],'logIndex':hex(e['log_index']),'data':'0x'+hex(int(e['amount_raw']))[2:].zfill(64)})
        return {'status':'0x1','from':A,'logs':logs}
    def test_transfer_to_pool_not_sale(self):
        e=event(1,A,P); self.assertEqual(detect_sales(T,[e],{e['tx_hash']:self.receipt([e])}),[])
    def test_swap_plus_counterasset(self):
        e=event(1,A,P); f=event(2,P,A,U,tx=e['tx_hash']); r=self.receipt([e,f]); ss=detect_sales(T,[e,f],{e['tx_hash']:r})
        self.assertEqual(len(ss),1); self.assertEqual(ss[0]['confidence'],'POSSIBLE'); self.assertIsNone(ss[0]['usd'])
    def test_failed_or_spoofed_receipt(self):
        e=event(1,A,P); f=event(2,P,A,U,tx=e['tx_hash']); r=self.receipt([e,f]); r['status']='0x0'
        self.assertEqual(detect_sales(T,[e,f],{e['tx_hash']:r}),[])
        r=self.receipt([e,f]); r['logs'][1]['data']='0x01'
        self.assertEqual(detect_sales(T,[e,f],{e['tx_hash']:r}),[])
class ConvergenceTests(unittest.TestCase):
    def test_multihop_and_downstream(self):
        origins=[event(1,F,A),event(2,F,B)]
        es=origins+[event(3,A,C),event(4,C,X),event(5,B,X),event(6,X,Y)]
        hubs,paths,truncated=convergence(es,[(A,T,origins[0]),(B,T,origins[1])],{})
        h=next(h for h in hubs if h['address']==X)
        self.assertEqual(h['source_count'],2); self.assertIn('e6',h['downstream_event_ids']); self.assertIsNone(h['attributable_proceeds']); self.assertFalse(truncated)
        self.assertTrue(any(p['addresses']==[A,C,X,Y] for p in paths))
    def test_no_time_travel_and_no_cross_asset(self):
        a=event(5,F,A); b=event(6,F,B)
        es=[a,b,event(1,A,X),event(2,B,X),event(7,A,C,U)]
        self.assertEqual(convergence(es,[(A,T,a),(B,T,b)],{})[0],[])
    def test_infrastructure_not_hub(self):
        a=event(1,F,A); b=event(2,F,B); es=[a,b,event(3,A,X),event(4,B,X),event(5,X,Y)]
        hs,ps,_=convergence(es,[(A,T,a),(B,T,b)],{X:'exchange'})
        self.assertEqual(hs,[]); self.assertFalse(any(p['destination']==Y for p in ps))
    def test_repeated_value_not_duplicated(self):
        a=event(1,F,A); b=event(2,F,B); es=[a,b,event(3,A,C),event(4,A,C),event(5,C,X),event(6,B,X)]
        hs,_,_=convergence(es,[(A,T,a),(B,T,b)],{})
        self.assertEqual(next(h for h in hs if h['address']==X)['observed_received_raw'],'200')
class ScoreTests(unittest.TestCase):
    def test_missing_evidence_is_unknown(self):
        s=scorecard([],[],[],[],[],T,False)
        self.assertTrue(all(x['value'] is None for x in s.values()))
if __name__=='__main__': unittest.main()
