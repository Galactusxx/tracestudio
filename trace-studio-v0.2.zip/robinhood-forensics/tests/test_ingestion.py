import unittest,tempfile
from app.core import *
from app.sources import *
A='0x'+'1'*40; B='0x'+'2'*40; TOKEN='0x'+'3'*40; TX='0x'+'a'*64
class IngestionTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.s=Store(self.tmp.name+'/db'); self.j=self.s.create_job(TOKEN)
        self.r=self.s.raw(self.j,'test','synthetic fixture',{})
    def tearDown(self): self.tmp.cleanup()
    def transfer(self): return {'block_number':10,'transaction_hash':TX,'log_index':1,'from':{'hash':A},'to':{'hash':B},'token':{'address_hash':TOKEN,'type':'ERC-20','decimals':'18'},'total':{'value':str(10**30+1)},'timestamp':'2026-01-01T00:00:00Z'}
    def test_dedupe(self):
        e=normalize_transfer(self.transfer(),self.r,20)
        self.s.event(self.j,e); self.s.event(self.j,e)
        self.assertEqual(len(self.s.events(self.j)),1); self.assertEqual(self.s.events(self.j)[0]['amount_raw'],str(10**30+1))
    def test_snapshot_and_nft(self):
        t=self.transfer(); self.assertIsNone(normalize_transfer(t,self.r,5))
        t['token']['type']='ERC-721'; self.assertIsNone(normalize_transfer(t,self.r,20))
    def test_mint_burn(self):
        t=self.transfer(); t['from']={'hash':ZERO}; self.assertEqual(normalize_transfer(t,self.r,20)['kind'],'mint')
        t['from']={'hash':A}; t['to']={'hash':DEAD}; self.assertEqual(normalize_transfer(t,self.r,20)['kind'],'burn')
    def test_pagination(self):
        c=Client(self.s,self.j); calls=[]
        def get(path,q):
            calls.append(q); c.last_raw=self.r
            return {'items':[self.transfer()],'next_page_params':{'block_number':9}} if len(calls)==1 else {'items':[],'next_page_params':None}
        c.get=get
        self.assertEqual(ingest_transfers(c,'/test',20)[0],1)
        self.assertEqual(calls[1]['block_number'],9)
        self.assertEqual(self.s.rows('SELECT exhausted FROM checkpoints')[0]['exhausted'],1)
    def test_failed_native_excluded(self):
        t={'block_number':1,'value':'1','hash':TX,'from':{'hash':A},'to':{'hash':B},'status':'error'}
        self.assertIsNone(normalize_native(t,self.r,10))
    def test_internal_root_not_double_counted(self):
        t={'block_number':1,'value':'1','transaction_hash':TX,'from':{'hash':A},'to':{'hash':B},'success':True,'index':0}
        self.assertIsNone(normalize_native(t,self.r,10,True))
if __name__=='__main__': unittest.main()
