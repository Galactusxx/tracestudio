// Development QA only. Requires Playwright + Chromium; no runtime dependencies.
const {chromium}=require('playwright');const fs=require('fs');const path=require('path');
(async()=>{
const base=process.env.BASE_URL||'http://127.0.0.1:8080',out=process.env.QA_DIR||'/data/qa';fs.mkdirSync(out,{recursive:true});
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/local/bin/chromium',headless:true,args:['--no-sandbox']});
const page=await browser.newPage({viewport:{width:1440,height:1080},colorScheme:'light'});const errors=[];page.on('pageerror',e=>errors.push(e.message));
const css=fs.readFileSync(path.join(__dirname,'../static/style.css'),'utf8');
async function save(name){await page.evaluate(()=>window.scrollTo(0,0));let html=(await page.content()).replace(/<script\b[^>]*>[\s\S]*?<\/script>/g,'').replace('<link rel="stylesheet" href="/style.css">','<style>'+css+'</style>');if(html.includes('<dialog id="detail" open=""'))html=html.replace('</body>','<script>const d=document.querySelector("dialog[open]");d.close();d.showModal();</script></body>');fs.writeFileSync(path.join(out,name+'.html'),html);const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth);if(overflow)throw Error(name+' has horizontal page overflow');}
await page.goto(base);await save('landing-desktop');await page.setViewportSize({width:390,height:844});await save('landing-mobile');await page.setViewportSize({width:1440,height:1080});
await page.fill('#address','0x1234');await page.click('#analyze');if(!(await page.locator('#error').isVisible()))throw Error('Validation error missing');await save('invalid-address');
for(const tab of ['methodology','sources']){await page.click(`[data-nav="${tab}"]`);await save(tab);}
await page.click('[data-nav="investigate"]');
// Route only the QA browser to synthetic fixtures; app source has no demo mode.
const fixture=JSON.parse(fs.readFileSync(path.join(out,'fixture.json'),'utf8'));
await page.route('**/api/investigations',r=>r.fulfill({status:202,contentType:'application/json',body:JSON.stringify({id:'a'.repeat(32)})}));
await page.route('**/api/jobs/*',r=>r.fulfill({status:200,contentType:'application/json',body:JSON.stringify(fixture)}));
await page.fill('#address',fixture.token);await page.click('#analyze');await page.waitForSelector('#report:not([hidden])');
await page.evaluate(()=>{const b=document.createElement('div');b.textContent='SYNTHETIC QA FIXTURE — NOT LIVE BLOCKCHAIN FINDINGS';b.style.cssText='padding:12px;background:#fbebde;color:#9b591e;font-weight:bold';document.body.prepend(b);});
for(const tab of ['Overview','Graph','Wallets','Sales','Convergence','Timeline','Evidence','Coverage']){await page.getByRole('button',{name:tab,exact:true}).click();await save('report-'+tab.toLowerCase());}
await page.getByRole('button',{name:'Graph',exact:true}).click();await page.locator('#graph-svg g[role=button]').first().click();await page.getByRole('button',{name:'Expand neighborhood'}).click();await page.getByRole('button',{name:'Zoom +',exact:true}).click();await page.getByRole('button',{name:'Reset view'}).click();
await page.locator('.toolbar select').nth(0).selectOption('proceeds');if(!(await page.locator('#graph-svg').textContent()).includes('No collected paths'))throw Error('Empty graph state missing');await save('graph-empty');await page.locator('.toolbar select').nth(0).selectOption('token');
await page.setViewportSize({width:390,height:844});await save('graph-mobile');
await page.getByRole('button',{name:'Evidence',exact:true}).click();await page.getByRole('button',{name:'View evidence ↗'}).first().click();await save('evidence-mobile');await page.click('#close-detail');
await page.setViewportSize({width:1440,height:1080});await page.getByRole('button',{name:'Wallets',exact:true}).click();await page.locator('tbody .text-button').first().click();await save('wallet-detail');
if(errors.length)throw Error(errors.join('\n'));
console.log('UI smoke passed: 8 report tabs, 3 navigation routes, validation, graph controls, evidence/wallet dialogs, 390px responsive overflow checks.');await browser.close();process.exit(0);
})().catch(e=>{console.error(e);process.exit(1)});
