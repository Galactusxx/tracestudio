PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS jobs (
 id TEXT PRIMARY KEY, token TEXT NOT NULL, chain_id INTEGER NOT NULL CHECK(chain_id=4663),
 status TEXT NOT NULL, stage TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 snapshot_block INTEGER, snapshot_hash TEXT, report_json TEXT, error TEXT
);
CREATE TABLE IF NOT EXISTS raw_responses (
 id TEXT PRIMARY KEY, job_id TEXT NOT NULL REFERENCES jobs(id), source TEXT NOT NULL,
 request_ref TEXT NOT NULL, fetched_at TEXT NOT NULL, payload_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS addresses (
 job_id TEXT NOT NULL REFERENCES jobs(id), address TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'unknown',
 label TEXT, label_source TEXT, raw_id TEXT REFERENCES raw_responses(id), PRIMARY KEY(job_id,address)
);
CREATE TABLE IF NOT EXISTS assets (
 job_id TEXT NOT NULL REFERENCES jobs(id), address TEXT NOT NULL, symbol TEXT, name TEXT, decimals INTEGER,
 total_supply_raw TEXT, raw_id TEXT REFERENCES raw_responses(id), PRIMARY KEY(job_id,address)
);
CREATE TABLE IF NOT EXISTS events (
 job_id TEXT NOT NULL REFERENCES jobs(id), id TEXT NOT NULL, chain_id INTEGER NOT NULL CHECK(chain_id=4663),
 tx_hash TEXT NOT NULL, block_number INTEGER NOT NULL, block_hash TEXT, tx_index INTEGER,
 log_index INTEGER, trace_id TEXT, timestamp TEXT, from_address TEXT NOT NULL, to_address TEXT NOT NULL,
 asset TEXT NOT NULL, amount_raw TEXT NOT NULL, decimals INTEGER, kind TEXT NOT NULL,
 raw_id TEXT NOT NULL REFERENCES raw_responses(id), PRIMARY KEY(job_id,id)
);
CREATE INDEX IF NOT EXISTS events_from ON events(job_id,from_address,block_number);
CREATE INDEX IF NOT EXISTS events_to ON events(job_id,to_address,block_number);
CREATE INDEX IF NOT EXISTS events_asset ON events(job_id,asset,block_number,tx_index,log_index);
CREATE INDEX IF NOT EXISTS events_tx ON events(job_id,tx_hash);
CREATE TABLE IF NOT EXISTS holders (
 job_id TEXT NOT NULL REFERENCES jobs(id), address TEXT NOT NULL, balance_raw TEXT NOT NULL,
 raw_id TEXT NOT NULL REFERENCES raw_responses(id), PRIMARY KEY(job_id,address)
);
CREATE TABLE IF NOT EXISTS checkpoints (
 job_id TEXT NOT NULL REFERENCES jobs(id), resource TEXT NOT NULL, cursor_json TEXT,
 pages INTEGER NOT NULL, exhausted INTEGER NOT NULL, error TEXT, PRIMARY KEY(job_id,resource)
);
CREATE TABLE IF NOT EXISTS findings (
 job_id TEXT NOT NULL REFERENCES jobs(id), id TEXT NOT NULL, category TEXT NOT NULL,
 score INTEGER, confidence TEXT NOT NULL, explanation_json TEXT NOT NULL, PRIMARY KEY(job_id,id)
);
CREATE TABLE IF NOT EXISTS finding_evidence (
 job_id TEXT NOT NULL, finding_id TEXT NOT NULL, event_id TEXT NOT NULL,
 PRIMARY KEY(job_id,finding_id,event_id),
 FOREIGN KEY(job_id,finding_id) REFERENCES findings(job_id,id),
 FOREIGN KEY(job_id,event_id) REFERENCES events(job_id,id)
);
