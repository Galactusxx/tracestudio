# TRACE Studio v0.2

Robinhood Chain token forensics with a redesigned investigation studio, authenticated case library, durable workers, source-backed enrichment, and explicit evidence boundaries.

**Release status: development / deployment candidate. NOT signed off for production.**

The application is runnable and tested locally, but the full requested forensic scope is not complete. The release check deliberately reports `release_ready: false`. See `docs/RELEASE-GATES.json` and the feature matrix below. Permission to proceed does not establish source availability, deploy a hosting environment, or validate missing protocols.

## Run locally

Python 3.11+; the local app has no third-party runtime dependencies.

```sh
cd robinhood-forensics
python3 -m app.server
```

Open **http://127.0.0.1:8080**. Paste one complete ERC-20 contract address. No RPC URL, transaction hash, wallet address, signature, or private key is required from the end user.

**Local mode is deliberately unauthenticated and binds only to loopback.** Do not expose it through a public tunnel. Production mode uses the separate authenticated WSGI entrypoint.

`trace-preview.html` is a self-contained interface preview. It does not run a backend or invent investigation results.

## What changed since v0.1

### Application and security

- Password authentication using scrypt (N=32768, r=8, p=3) with random salts.
- Opaque, hashed session tokens; Secure / HttpOnly / SameSite=Strict cookies in production; eight-hour expiry and logout invalidation.
- Per-account authorization on investigations, event pagination, raw evidence, exports, and cancellation. Job references are not authorization.
- CSRF tokens, exact origin checks, explicit production Host allowlist, CSP, security headers, bounded request bodies.
- Persistent per-account and sign-in rate limits; audit records; submission idempotency.
- Durable SQLite queue, bounded capacity, exclusive leases, heartbeat recovery, three-attempt crash limit, cooperative cancellation, and transactionally fenced stale-worker writes.
- Crash-safe cached page replay with idempotent event inserts. Recovery retains the original snapshot and refuses changed block hashes.
- Separate web and worker processes, streaming raw-response exports, paginated event API, consistent database backup command.

### Investigation enrichment

- Official Uniswap v3 infrastructure registry from the chain-specific Uniswap deployment documentation.
- Simple-swap pool membership verified by checking the official factory's `getPool(token0, token1, fee)` at the investigation snapshot.
- Successful receipt transfer matching plus signed v3 swap-delta checks; callback output-before-input ordering is not mistaken for invalid execution.
- Event-reconstructed holder window peaks and opening balances, only when the event ledger reconciles and ordering is available.
- FIFO holding-period estimates with explicit accounting convention and unknown opening-lot coverage.
- Conservative arbitrary-mixing lower/upper bound engine. The automatic report refuses attribution where independent opening balances and complete per-asset ledgers are absent. It does not label mere reachability as attributable proceeds.
- Optional CoinGecko Pro historical USD adapter: previous fully closed one-minute candle, at most five minutes stale, exact asset matching, no current-price backfill, no stablecoin=$1 assumption, no full total when any sale remains unpriced.
- Contract-reported `owner()` observation where supported; not a full authority or identity audit.

### Interface

- New editorial light/dark design, responsive layout, conceptual investigation diagram explicitly labeled as not live data.
- Sign-in, saved case library, cancellation, authenticated raw evidence, report export.
- Layered directed graph layout, zoom/pan, collected-neighborhood expansion, asset/time/type filters, relationship and convergence highlights.
- Eight report views: overview, graph, wallets, sales, convergence, timeline, evidence, coverage.

## Feature scope — implemented vs incomplete

| Requirement group | Current behavior | Important limit |
|---|---|---|
| One-address investigation | Chain ID, checksum, code and ERC-20 method checks; automatic staged job | Source connectivity is required |
| Token discovery | Metadata, supply, holders, transfers, mint/burn patterns, creator metadata | Metadata/API completeness varies |
| Token provenance | Recursive observed token paths | Not a full treasury/vesting/allocation/authority audit |
| Holder analysis | Snapshot balances for prioritized wallets; latest indexer balances kept separate; conditional window peak/FIFO | Lifetime maxima and initial funding are not proven |
| Relationships | Multi-family evidence thresholds, repeated destinations, funding and direct-transfer signals | No ownership assertions; advanced clustering models not implemented |
| Funding | Earliest observed native funding and bounded neighborhoods | Not necessarily initial lifetime funding or actual gas payer |
| Token/proceeds flow | Separate linked graphs and evidence paths | Same-asset downstream tracing; bounded depth |
| Selling | Simple receipt-backed v2/v3 candidates; verified simple v3 swaps | V4, intents, arbitrary aggregator routes, native-ETH swaps, exchange execution unsupported |
| Coordination | Temporal co-selling and repeated windows | Heuristic, not calibrated or proof of coordination |
| Convergence/consolidation | Direct/multi-hop reachability, repetition, unique terminal transfers, downstream evidence | Unknown services can still be false positives |
| Attribution | Conservative interval engine with strict input prerequisites | Automatic sample does not yet collect all required independent opening balances/complete ledgers |
| USD valuation | Optional historical provider estimates and coverage | Requires operator's provider key and indexed history |
| Exchange/bridge analysis | Source-backed labels can exclude infrastructure | No complete verified exchange registry or cross-chain settlement resolver |
| Scoring | Explainable relationship/coordination/convergence/consolidation heuristics | Overall/provenance scores remain uncalibrated and not invented |
| Persistence | SQLite WAL, indexed evidence, graph projections, durable jobs/cache | Single-node bounded system; not proven at million-wallet scale |
| Production deployment | Authenticated WSGI entrypoint, Gunicorn/Caddy/container configuration | Container build, dependency scan, public TLS, restore/load tests not validated here |

**No qualifying findings is not an all-clear.** A complete job means configured stages finished, not that the entire blockchain was exhaustively analyzed. Reports retain `partial` status for bounded coverage.

## Production deployment candidate

Deployment assets are in `deploy/`. These files were syntax-checked, **not successfully built or deployed in this sandbox**.

1. Provision a Linux host with Docker Compose and outbound DNS/HTTPS to Robinhood RPC, Blockscout, package/image registries, and the optional price provider.
2. Point an owned domain at the host. Open ports 80/443 for Caddy's TLS provisioning.
3. Copy `deploy/env.example` to `deploy/.env`, set `TRACE_DOMAIN`, and configure provider credentials on the host. **Do not paste secrets into chat or commit them.**
4. Build and scan the images/dependencies. Pin approved container images by digest before public deployment; the supplied development tags are not an approved supply-chain lock.
5. Start the services:

```sh
docker compose --env-file deploy/.env -f deploy/compose.yaml build
docker compose --env-file deploy/.env -f deploy/compose.yaml up -d
```

6. Create an operator account (password is prompted, not printed):

```sh
docker compose --env-file deploy/.env -f deploy/compose.yaml exec web \
  python -m app.admin create-user investigator
```

7. Confirm public HTTPS, sign-in/logout, CSRF rejection, cross-user isolation, cancellation/recovery, and evidence exports. Test realistic data volumes and providers before inviting users.
8. Run the release check and close all open gates. The full-scope gate remains blocked until the missing protocol/history/cross-chain features are implemented and validated.

Production WSGI entrypoint: `app.hardened:application`.
Worker: `python -m app.worker`.
The WSGI server and worker share **one local SQLite volume**. Do not put the database on an unreliable network filesystem or scale replicas across hosts. A distributed PostgreSQL/object-storage/queue migration remains future work.

## Operator configuration

| Variable | Purpose |
|---|---|
| `TRACE_ENV` | `production` for the authenticated WSGI app; default for that entrypoint |
| `TRACE_ALLOWED_HOSTS` | Comma-separated exact hostnames; required in production |
| `FORENSICS_DB` | Persistent SQLite path |
| `ROBINHOOD_RPC` | Optional provider override; chain ID 4663 is always enforced |
| `BLOCKSCOUT_API_KEY` | Optional Pro key; otherwise the public Blockscout API is attempted |
| `COINGECKO_PRO_API_KEY` | Optional historical valuation provider key |

Endpoints default to `https://rpc.mainnet.chain.robinhood.com` and `https://robinhoodchain.blockscout.com/api/v2`. Native gas asset: ETH. Production users still enter only a token address after signing in.

`labels.json`, if supplied by the operator, requires a public HTTPS source for every label. Unknown entities are never assigned a real-world owner by the system.

## Tests and validation

```sh
python3 -m unittest discover -s tests -v
python3 -m compileall -q app
node --check static/app.js
```

**58 tests passed** in the assembled v0.2 build. They cover validation, exact amounts, deduplication, pagination, snapshot/reorg handling, conservative detectors, password/session security, access isolation, CSRF/origin checks, worker leases/cancellation/fencing/recovery, page replay, holder accounting, pricing rules and pool-factory verification.

A separate browser test exercised **real local HTTPS sign-in**, secure cookies, CSRF-backed job submission, the worker, authenticated raw evidence, saved cases, logout invalidation, light/dark themes, responsive layout and all eight report tabs. It uses an isolated temporary database and clearly labeled synthetic fixtures, never production demo data.

Development-only browser dependencies: Playwright/Chromium and Python `cryptography` for a temporary localhost test certificate.

```sh
# Terminal 1, QA only:
python3 tests/secure_ui_server.py
# Terminal 2:
node tests/secure-ui.cjs
```

`tests/ui-smoke.cjs` remains available for the loopback development server; set `BASE_URL` if changing its port.

## Release-gate result

The build sandbox cannot resolve the live RPC/indexer or package-registry hosts. Gunicorn is not installed here, Docker is unavailable, and no public hosting domain was supplied. The real source check correctly failed without creating blockchain findings.

Run:

```sh
python3 -m app.release_check
```

The included `docs/RELEASE-GATES.json` records the actual blocked/unverified results. Local tests do not certify live-chain correctness, security under adversarial load, or production readiness.

## Operations

- Back up with SQLite's consistent backup API, not by copying only the main file while WAL writes are active:

```sh
python3 -m app.admin backup /secure-backups/trace-backup.sqlite3
```

- Backups contain case data and credential hashes. Encrypt and restrict access; test restoration into an isolated environment. The CLI refuses to overwrite an existing destination.
- Monitor worker heartbeat age, queue age, source errors/429s, failed/recovered jobs, storage growth, and authentication failures.
- Define a retention policy before public operation. No automated deletion policy is enabled by default.
- Audit entries record actions, not passwords/provider keys. Raw source references omit configured provider credentials.
- Default job limits are in `app/pipeline.py`: bounded token/holder pages, prioritized wallet/depth limits, inspected receipts, path counts, and source-request budget. No blind full-chain crawl.

## Sources

- Robinhood network: https://docs.robinhood.com/chain/connecting
- Robinhood deployment guide: https://docs.robinhood.com/chain/deploy-smart-contracts/
- Blockscout: https://docs.blockscout.com/robinhood-api
- Uniswap v3 Robinhood deployment registry: https://developers.uniswap.org/docs/protocols/v3/deployments/v3-robinhood-chain-deployments
- Historical price schema: https://docs.coingecko.com/reference/pool-ohlcv-contract-address

This is an independent read-only analytics application, not an official Robinhood service. Observable on-chain relationships are not proof of common ownership or identity.
