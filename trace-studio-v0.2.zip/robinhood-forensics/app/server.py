"""Loopback-only development runner. Production: Gunicorn app.hardened:application."""
import argparse,threading,secrets
from wsgiref.simple_server import make_server
from .core import Store
from .hardened import create_app,work_once

def main():
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8080);a=p.parse_args();s=Store();stop=threading.Event();worker=secrets.token_hex(12)
    def loop():
        while not stop.is_set():
            if not work_once(s,worker):stop.wait(1)
    threading.Thread(target=loop,daemon=True).start()
    server=make_server('127.0.0.1',a.port,create_app(s,production=False));print(f'Local development: http://127.0.0.1:{a.port}',flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:stop.set();server.server_close()
if __name__=='__main__':main()
