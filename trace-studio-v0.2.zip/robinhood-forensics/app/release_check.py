"""Evidence-based release gate. This script does NOT certify analytical completeness."""
import json,sys,os,tempfile,importlib.util,subprocess
from .core import Store
from .sources import Client,discover

def main():
 results=[]
 def gate(name,fn):
  try:detail=fn();results.append({'gate':name,'status':'pass','detail':detail})
  except Exception as e:results.append({'gate':name,'status':'blocked','detail':str(e)[:400]})
 def gunicorn():
  if importlib.util.find_spec('gunicorn') is None:raise RuntimeError('Production WSGI server not installed; install deploy/requirements.txt')
  return 'Production WSGI server importable'
 gate('production_server_dependency',gunicorn)
 def live():
  with tempfile.TemporaryDirectory() as d:
   s=Store(d+'/probe.db');token='0xd4052415613b34af236024b895574c467f65b6dd';j=s.create_job(token);c=Client(s,j,budget=30)
   m=discover(c,token);items=c.get('/tokens/'+token+'/transfers')
   if not isinstance(items.get('items'),list):raise RuntimeError('Unexpected live indexer transfer schema')
   return {'chain_id':4663,'snapshot_block':m['snapshot_block'],'symbol':m['symbol'],'transfer_page_rows':len(items['items'])}
 gate('live_rpc_and_indexer',live)
 gate('configured_public_host',lambda:os.environ['TRACE_ALLOWED_HOSTS'])
 # These need actual operational evidence, not environment flags that pretend a test ran.
 results.extend([{'gate':'container_build_security_scan','status':'unverified','detail':'Run the documented clean build, dependency/image scans, and pin approved image digests.'},{'gate':'production_tls_restore_load_test','status':'unverified','detail':'Validate HTTPS, cross-user access, backup restore, and capacity on the target hosting environment.'},{'gate':'full_requested_forensic_scope','status':'blocked','detail':'V4/intent/complex aggregator/native swap decoding, full cross-chain resolution, and exhaustive history are not implemented.'}])
 print(json.dumps({'release_ready':False,'gates':results},indent=2))
 return 1
if __name__=='__main__':sys.exit(main())
