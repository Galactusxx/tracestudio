import secrets,threading,signal
from .core import Store
from .hardened import work_once

def main():
    s=Store();worker=secrets.token_hex(12);stop=threading.Event()
    for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,lambda *_:stop.set())
    while not stop.is_set():
        if not work_once(s,worker):stop.wait(1)
if __name__=='__main__':main()
