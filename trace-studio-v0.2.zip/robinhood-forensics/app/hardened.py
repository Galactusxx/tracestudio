"""Authenticated WSGI API and durable single-node worker. No on-chain writes."""
import os,json,time,secrets,hashlib,hmac,re,threading,logging
from http.cookies import SimpleCookie
from .core import Store,ROOT,now,address

def migrate(c):
    c.execute('BEGIN IMMEDIATE')
    cols={r[1] for r in c.execute('PRAGMA table_info(jobs)')}
    for n,t in {'owner_id':'TEXT','lease_owner':'TEXT','lease_until':'REAL','attempts':'INTEGER NOT NULL DEFAULT 0','cancel_requested':'INTEGER NOT NULL DEFAULT 0','idempotency_key':'TEXT'}.items():
        if n not in cols:c.execute(f'ALTER TABLE jobs ADD COLUMN {n} {t}')
    for sql in [
      'CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,username TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,disabled INTEGER NOT NULL DEFAULT 0)',
      'CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),csrf TEXT NOT NULL,expires REAL NOT NULL)',
      'CREATE TABLE IF NOT EXISTS limits(bucket TEXT PRIMARY KEY,started REAL NOT NULL,hits INTEGER NOT NULL)',
      'CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT NOT NULL,actor TEXT,action TEXT NOT NULL,object_id TEXT)',
      'CREATE TABLE IF NOT EXISTS workers(id TEXT PRIMARY KEY,heartbeat REAL NOT NULL)',
      'CREATE TABLE IF NOT EXISTS page_cache(job_id TEXT NOT NULL,resource TEXT NOT NULL,page INTEGER NOT NULL,raw_id TEXT NOT NULL REFERENCES raw_responses(id),PRIMARY KEY(job_id,resource,page))',
      'CREATE UNIQUE INDEX IF NOT EXISTS job_idempotency ON jobs(owner_id,idempotency_key) WHERE idempotency_key IS NOT NULL',
      'CREATE INDEX IF NOT EXISTS job_queue ON jobs(status,lease_until,created_at)',
      'CREATE INDEX IF NOT EXISTS job_owner ON jobs(owner_id,created_at)']:
        c.execute(sql)
    c.commit()

def audit(s,actor,action,j=None):s.execute('INSERT INTO audit(at,actor,action,object_id) VALUES(?,?,?,?)',(now(),actor,action,j))
def password_hash(p,salt=None):
    if not isinstance(p,str) or not 14<=len(p)<=256:raise ValueError('Password must be 14–256 characters')
    salt=salt or secrets.token_hex(16)
    v=hashlib.scrypt(p.encode(),salt=bytes.fromhex(salt),n=32768,r=8,p=3,maxmem=128*1024*1024,dklen=32)
    return salt+'$'+v.hex()
def create_user(s,name,password):
    if not re.fullmatch(r'[a-zA-Z0-9_.@+-]{3,100}',name):raise ValueError('Invalid username')
    uid=secrets.token_hex(16);s.execute('INSERT INTO users VALUES(?,?,?,0)',(uid,name.lower(),password_hash(password)));audit(s,uid,'user_created');return uid
def login(s,name,password):
    rows=s.rows('SELECT * FROM users WHERE username=? AND disabled=0',(str(name).lower(),));stored=rows[0]['password_hash'] if rows else '00'*16+'$'+'00'*32
    try:valid=hmac.compare_digest(password_hash(password,stored.split('$')[0]),stored)
    except (TypeError,ValueError):valid=False
    if not valid:raise ValueError('Invalid username or password')
    token=secrets.token_urlsafe(48);csrf=secrets.token_urlsafe(32)
    s.execute('INSERT INTO sessions VALUES(?,?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),rows[0]['id'],csrf,time.time()+28800))
    s.execute('DELETE FROM sessions WHERE expires<?',(time.time(),));audit(s,rows[0]['id'],'login')
    return token,{'id':rows[0]['id'],'username':rows[0]['username'],'csrf':csrf}
def session(s,token):
    if not token or len(token)>200:return None
    rows=s.rows('SELECT users.id,username,csrf FROM sessions JOIN users ON users.id=sessions.user_id WHERE token_hash=? AND expires>? AND disabled=0',(hashlib.sha256(token.encode()).hexdigest(),time.time()))
    return rows[0] if rows else None
def allowed(s,bucket,limit,window=60):
    t=time.time()
    with s.connect() as c:
        c.execute('BEGIN IMMEDIATE');r=c.execute('SELECT started,hits FROM limits WHERE bucket=?',(bucket,)).fetchone()
        start,hits=(t,0) if not r or t-r[0]>=window else (r[0],r[1])
        c.execute('INSERT OR REPLACE INTO limits VALUES(?,?,?)',(bucket,start,hits+1));return hits<limit

def enqueue(s,owner,token,key=None):
    if key is not None and (not isinstance(key,str) or not 1<=len(key)<=100):raise ValueError('Invalid idempotency key')
    with s.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        if key:
            old=c.execute('SELECT id,token FROM jobs WHERE owner_id=? AND idempotency_key=?',(owner,key)).fetchone()
            if old:
                if old['token']!=token:raise ValueError('Idempotency key already used for another token')
                return old['id']
        if c.execute("SELECT count(*) FROM jobs WHERE status IN ('queued','running')").fetchone()[0]>=32:raise ValueError('Queue full')
        if c.execute("SELECT count(*) FROM jobs WHERE owner_id=? AND status IN ('queued','running')",(owner,)).fetchone()[0]>=3:raise ValueError('Three active investigations already queued')
        j=secrets.token_hex(16)
        c.execute('INSERT INTO jobs(id,token,chain_id,status,stage,created_at,updated_at,owner_id,idempotency_key) VALUES(?,?,4663,?,?,?,?,?,?)',(j,token,'queued','Queued',now(),now(),owner,key))
    audit(s,owner,'queued',j);return j

def claim(s,worker,lease=90):
    with s.connect() as c:
        c.execute('BEGIN IMMEDIATE');t=time.time()
        c.execute("UPDATE jobs SET status='failed',error='Worker retry limit reached' WHERE status='running' AND lease_until<? AND attempts>=3",(t,))
        r=c.execute("SELECT id FROM jobs WHERE cancel_requested=0 AND attempts<3 AND (status='queued' OR (status='running' AND lease_until<?)) ORDER BY created_at LIMIT 1",(t,)).fetchone()
        if not r:return None
        c.execute("UPDATE jobs SET status='running',lease_owner=?,lease_until=?,attempts=attempts+1,updated_at=? WHERE id=?",(worker,t+lease,now(),r['id']));return r['id']
def cancel(s,owner,j):
    s.execute("UPDATE jobs SET cancel_requested=1,status=CASE WHEN status='queued' THEN 'cancelled' ELSE status END WHERE id=? AND owner_id=? AND status IN ('queued','running')",(j,owner));audit(s,owner,'cancel_requested',j)
def work_once(s,worker,runner=None):
    from .core import Cancelled,LeaseLost
    from .pipeline import run
    s.execute('INSERT OR REPLACE INTO workers VALUES(?,?)',(worker,time.time()));j=claim(s,worker)
    if not j:return False
    stop=threading.Event()
    def beat():
        while not stop.wait(15):
            s.execute('INSERT OR REPLACE INTO workers VALUES(?,?)',(worker,time.time()))
            s.execute("UPDATE jobs SET lease_until=? WHERE id=? AND lease_owner=? AND status='running'",(time.time()+90,j,worker))
    thread=threading.Thread(target=beat,daemon=True);thread.start();task=Store(s.path);task.lease_job=j;task.lease_owner=worker
    try:(runner or run)(task,j)
    except Cancelled:s.execute("UPDATE jobs SET status='cancelled',stage='Cancelled by user',report_json=NULL WHERE id=? AND lease_owner=?",(j,worker))
    except LeaseLost:pass
    except Exception:
        logging.exception('worker_failed');s.execute("UPDATE jobs SET status='failed',error='Worker failure; inspect logs' WHERE id=? AND lease_owner=?",(j,worker))
    finally:
        stop.set();thread.join(2);s.execute("UPDATE jobs SET lease_owner=NULL,lease_until=NULL WHERE id=? AND lease_owner=? AND status NOT IN ('queued','running')",(j,worker))
    return True

class HTTPError(Exception):
    def __init__(self,status,message):self.status=status;self.message=message
HEADERS=[('X-Content-Type-Options','nosniff'),('Referrer-Policy','no-referrer'),('Cache-Control','no-store'),('Permissions-Policy','camera=(), microphone=(), geolocation=()'),('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")]
def create_app(s=None,production=True,hosts=None):
    s=s or Store();hosts=hosts or {x.strip() for x in os.environ.get('TRACE_ALLOWED_HOSTS','').split(',') if x.strip()}
    if production and not hosts:raise RuntimeError('Set TRACE_ALLOWED_HOSTS in production')
    hosts=hosts or {'127.0.0.1','localhost'}
    def app(env,start):
        rid=secrets.token_hex(12);headers=HEADERS+[('X-Request-ID',rid)]+([('Strict-Transport-Security','max-age=31536000')] if production else [])
        def respond(code,obj,extra=[]):
            payload=json.dumps(obj).encode();start(str(code)+' '+('OK' if code<400 else 'Error'),headers+[('Content-Type','application/json'),('Content-Length',str(len(payload)))]+extra);return [payload]
        try:
            host=env.get('HTTP_HOST','').lower();hostname=host.split(':')[0]
            if hostname not in hosts:raise HTTPError(403,'Host not allowed')
            method=env.get('REQUEST_METHOD','GET');path=env.get('PATH_INFO','/')
            if method not in ('GET','POST'):raise HTTPError(400,'Unsupported method')
            body={}
            if method=='POST':
                origin=env.get('HTTP_ORIGIN')
                if origin and origin not in ('https://'+host,'http://'+host if not production else ''):raise HTTPError(403,'Origin not allowed')
                if env.get('CONTENT_TYPE','').split(';')[0]!='application/json':raise HTTPError(415,'JSON required')
                try:n=int(env.get('CONTENT_LENGTH','0'))
                except ValueError:raise HTTPError(400,'Invalid length')
                if not 1<=n<=4096:raise HTTPError(413,'Body too large')
                try:body=json.loads(env['wsgi.input'].read(n))
                except (ValueError,UnicodeDecodeError):raise HTTPError(400,'Invalid JSON')
                if not isinstance(body,dict):raise HTTPError(400,'JSON object required')
            if path in ('/','/app.js','/style.css') and method=='GET':
                name,mime={'/':('index.html','text/html; charset=utf-8'),'/app.js':('app.js','text/javascript; charset=utf-8'),'/style.css':('style.css','text/css; charset=utf-8')}[path]
                data=(ROOT/'static'/name).read_bytes();start('200 OK',headers+[('Content-Type',mime),('Content-Length',str(len(data)))]);return [data]
            if path=='/healthz':return respond(200,{'status':'ok'})
            cookies=SimpleCookie();cookies.load(env.get('HTTP_COOKIE',''));token=cookies.get('trace_session');token=token.value if token else '';user=session(s,token)
            if not production:user=user or {'id':'local-operator','username':'Local operator','csrf':'development-only'}
            if path=='/api/session':return respond(200,{'authenticated':bool(user),'user':user,'mode':'production' if production else 'local'})
            if path=='/api/login' and method=='POST':
                ip=env.get('REMOTE_ADDR','unknown');name=str(body.get('username','')).lower()
                if not allowed(s,'login-ip:'+ip,15,900) or not allowed(s,'login-name:'+name,8,900):raise HTTPError(429,'Too many sign-in attempts')
                try:t,u=login(s,name,body.get('password',''))
                except ValueError:raise HTTPError(401,'Invalid username or password')
                cookie='trace_session='+t+'; Path=/; HttpOnly; SameSite=Strict; Max-Age=28800'+('; Secure' if production else '')
                return respond(200,{'user':u},[('Set-Cookie',cookie)])
            if not user:raise HTTPError(401,'Sign in to access investigations')
            owner=user['id']
            if method=='POST' and production and not hmac.compare_digest(env.get('HTTP_X_CSRF_TOKEN',''),user['csrf']):raise HTTPError(403,'CSRF token invalid')
            if not allowed(s,'api:'+owner,240):raise HTTPError(429,'Rate limit exceeded')
            if path=='/api/logout' and method=='POST':
                s.execute('DELETE FROM sessions WHERE token_hash=?',(hashlib.sha256(token.encode()).hexdigest(),));return respond(200,{'ok':True},[('Set-Cookie','trace_session=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict'+('; Secure' if production else ''))])
            if path in ('/readyz','/api/health'):
                n=s.rows('SELECT count(*) AS n FROM workers WHERE heartbeat>?',(time.time()-60,))[0]['n'];return respond(200 if n or path=='/api/health' else 503,{'active_workers':n,'network_verified':False,'scope':'Service health only; source connectivity checked per job'})
            if path=='/api/investigations' and method=='POST':
                if not allowed(s,'submit:'+owner,6,3600):raise HTTPError(429,'Submission rate exceeded')
                try:j=enqueue(s,owner,address(body.get('address')),env.get('HTTP_IDEMPOTENCY_KEY'))
                except ValueError as e:raise HTTPError(400,str(e))
                return respond(202,{'id':j,'status':'queued'})
            if path=='/api/jobs' and method=='GET':return respond(200,{'items':s.rows('SELECT id,token,status,stage,created_at,updated_at FROM jobs WHERE owner_id=? ORDER BY created_at DESC LIMIT 50',(owner,))})
            match=re.fullmatch(r'/api/jobs/([a-f0-9]{32})(?:/(cancel|export|events|evidence)(?:/([a-f0-9]{64}))?)?',path)
            if not match:raise HTTPError(404,'Not found')
            j,action,raw=match.groups()
            if not s.rows('SELECT id FROM jobs WHERE id=? AND owner_id=?',(j,owner)):raise HTTPError(404,'Investigation not found')
            if action=='cancel' and method=='POST':cancel(s,owner,j);return respond(200,{'cancel_requested':True})
            if method!='GET':raise HTTPError(404,'Not found')
            if action is None:
                d=s.job(j)
                for k in ('owner_id','lease_owner','lease_until','idempotency_key'):d.pop(k,None)
                return respond(200,d)
            if action=='events':
                from urllib.parse import parse_qs
                q=parse_qs(env.get('QUERY_STRING',''))
                try:offset=max(0,int(q.get('offset',['0'])[0]));limit=max(1,min(200,int(q.get('limit',['50'])[0])))
                except ValueError:raise HTTPError(400,'Invalid pagination')
                rows=s.rows('SELECT * FROM events WHERE job_id=? ORDER BY block_number,tx_index,log_index,id LIMIT ? OFFSET ?',(j,limit+1,offset));return respond(200,{'items':rows[:limit],'next_offset':offset+limit if len(rows)>limit else None})
            if action=='evidence' and raw:
                rows=s.rows('SELECT * FROM raw_responses WHERE job_id=? AND id=?',(j,raw))
                if not rows:raise HTTPError(404,'Evidence not found')
                r=rows[0];r['payload']=json.loads(r.pop('payload_json'));return respond(200,r)
            if action=='export':
                audit(s,owner,'evidence_exported',j);start('200 OK',headers+[('Content-Type','application/json'),('Content-Disposition','attachment; filename="trace-'+j+'.json"')])
                def stream():
                    yield b'{"investigation":'+json.dumps(s.job(j)).encode()+b',"raw_responses":['
                    with s.connect() as c:
                        first=True
                        for row in c.execute('SELECT * FROM raw_responses WHERE job_id=? ORDER BY fetched_at,id',(j,)):
                            r=dict(row);r['payload']=json.loads(r.pop('payload_json'));yield (b'' if first else b',')+json.dumps(r).encode();first=False
                    yield b']}'
                return stream()
            raise HTTPError(404,'Not found')
        except HTTPError as e:return respond(e.status,{'error':e.message,'request_id':rid})
        except Exception:logging.exception('request_failed '+rid);return respond(500,{'error':'Internal error; contact operator with request reference','request_id':rid})
    return app
_app=None
def application(env,start):
    global _app
    if _app is None:_app=create_app(production=os.environ.get('TRACE_ENV','production')=='production')
    return _app(env,start)
