"""Staged, bounded investigation orchestration. Live data only in production."""
import json, os
from collections import defaultdict, Counter, deque
from .core import *
from .sources import *
from .detectors import *
from .enrichment import REGISTRY,enrich,verify_swap_deltas,holder_history,fifo_age,attribution_bounds,value_sales

LIMITS={'token_pages':20,'holder_pages':5,'address_pages':1,'seed_wallets':12,'trace_wallets':30,'trace_depth':3,'path_depth':4,'sale_receipts':20,'requests':640,'paths':3000}

def run(store,job,client_factory=Client):
    token=store.job(job)['token']; c=client_factory(store,job,budget=LIMITS['requests']); warnings=[]; meta=None
    def stage(text): store.update(job,status='running',stage=text)
    def optional(label,fn,default=None):
        try: return fn()
        except (SourceError,ValueError,TypeError,KeyError) as e:
            warnings.append(label+': '+str(e)); return default
    try:
        stage('1 / 8 · Validating network and discovering token')
        meta=discover(c,token); warnings.extend(meta.pop('warnings'))
        t=optional('Explorer token metadata',lambda:c.get('/tokens/'+token),{})
        meta['holder_count']=t.get('holders_count'); meta['holder_count_basis']='Indexer at retrieval, not snapshot'
        a=optional('Contract creation',lambda:c.get('/addresses/'+token),{})
        meta['deployer']=addr(a.get('creator_address_hash')); meta['creation_transaction']=a.get('creation_transaction_hash')
        stage('2 / 8 · Collecting holders and target-token history')
        def holders():
            for items,rid in c.pages('/tokens/'+token+'/holders',max_pages=LIMITS['holder_pages']):
                for h in items:
                    w=addr(h.get('address'))
                    if w and h.get('value') is not None:
                        store.execute('INSERT OR REPLACE INTO holders VALUES(?,?,?,?)',(job,w,str(int(h['value'])),rid))
        optional('Current holders',holders)
        ingested=optional('Target token history',lambda:ingest_transfers(c,'/tokens/'+token+'/transfers',meta['snapshot_block'],max_pages=LIMITS['token_pages']))
        fallback=None
        if ingested is None or not store.events(job):
            fallback=optional('Bounded RPC log fallback',lambda:rpc_transfer_fallback(c,token,meta))
        es=store.events(job); target=[e for e in es if e['asset']==token]
        weight=Counter()
        for e in target:
            weight[e['from_address']]+=int(e['amount_raw']); weight[e['to_address']]+=int(e['amount_raw'])
        hh=store.rows('SELECT * FROM holders WHERE job_id=?',(job,)); hh.sort(key=lambda h:int(h['balance_raw']),reverse=True)
        top=[h['address'] for h in hh[:6]]+[w for w,_ in weight.most_common(LIMITS['seed_wallets'])]
        seeds=list(dict.fromkeys(w for w in top if w not in (ZERO,DEAD,token)))[:LIMITS['seed_wallets']]
        if meta['deployer'] and meta['deployer'] not in seeds: seeds=([meta['deployer']]+seeds)[:LIMITS['seed_wallets']]
        stage('3 / 8 · Classifying priority wallets and tracing flows')
        kinds={ZERO:'burn',DEAD:'burn',token:'contract',**{a:m['kind'] for a,m in REGISTRY.items()}}; labels=dict(REGISTRY); balances={}; queued=set(seeds); seen=set(); queue=deque((w,0) for w in seeds)
        # Optional operator-maintained labels require a public source URL. No guessed identities.
        registry=json.loads((ROOT/'labels.json').read_text()) if (ROOT/'labels.json').exists() else {}
        for w,label in registry.items():
            if not label.get('source','').startswith('https://'): continue
            w=address(w); kinds[w]=label['kind']; labels[w]=label
        while queue and len(seen)<LIMITS['trace_wallets'] and c.calls<c.budget-35:
            w,depth=queue.popleft()
            if w in seen or w in (ZERO,DEAD,token): continue
            seen.add(w)
            code=optional('Address classification '+w,lambda:c.rpc('eth_getCode',[w,hex(meta['snapshot_block'])]))
            if w not in kinds: kinds[w]='eoa' if code=='0x' else 'contract' if code else 'unknown'
            store.execute('INSERT OR REPLACE INTO addresses VALUES(?,?,?,?,?,?)',(job,w,kinds[w],labels.get(w,{}).get('label'),labels.get(w,{}).get('source'),c.last_raw))
            if w in seeds:
                value=optional('Snapshot holder balance '+w,lambda:uint(c.rpc('eth_call',[{'to':token,'data':'0x70a08231'+w[2:].zfill(64)},hex(meta['snapshot_block'])])))
                if value is not None: balances[w]=str(value)
            if kinds.get(w) in INFRA: continue
            optional('Wallet token transfers '+w,lambda:ingest_transfers(c,'/addresses/'+w+'/token-transfers',meta['snapshot_block'],max_pages=LIMITS['address_pages']))
            for endpoint,internal in [('transactions',False),('internal-transactions',True)]:
                def native(endpoint=endpoint,internal=internal):
                    for items,rid in c.pages('/addresses/'+w+'/'+endpoint,max_pages=LIMITS['address_pages']):
                        for t in items:
                            e=normalize_native(t,rid,meta['snapshot_block'],internal)
                            if e: store.event(job,e)
                optional('Native '+endpoint+' '+w,native)
            if depth<LIMITS['trace_depth']:
                local=[e for e in store.events(job) if w in (e['from_address'],e['to_address'])]
                rank=Counter()
                for e in local:
                    other=e['to_address'] if e['from_address']==w else e['from_address']; rank[other]+=1
                for other,_ in rank.most_common(8):
                    if other not in queued and other not in (ZERO,DEAD,token) and kinds.get(other) not in INFRA:
                        queued.add(other); queue.append((other,depth+1))
        if queue: warnings.append('Priority trace capped; not all related wallets or downstream destinations were explored.')
        stage('4 / 8 · Checking swap receipts and linking counterassets')
        es=store.events(job); txs=[]
        for e in sorted(es,key=lambda e:int(e['amount_raw']) if e['asset']==token else -1,reverse=True):
            if e['asset']==token and e['from_address'] in seen and e['to_address'] not in (ZERO,DEAD) and kinds.get(e['from_address']) not in INFRA:
                if e['tx_hash'] not in txs: txs.append(e['tx_hash'])
        receipts={}
        for tx in txs[:LIMITS['sale_receipts']]:
            if c.calls>=c.budget-80: break
            r=optional('Swap receipt '+tx,lambda:c.rpc('eth_getTransactionReceipt',[tx]))
            if not r or int(r.get('blockNumber','0x0'),16)>meta['snapshot_block']: continue
            r['_raw_id']=c.last_raw
            # Include all ERC-20-shaped transfers from successful receipt, not just the target.
            if r.get('status')=='0x1':
                stamp=next((e['timestamp'] for e in es if e['tx_hash']==tx),None)
                for l in r.get('logs',[]):
                    if l.get('removed') or len(l.get('topics',[]))!=3 or l['topics'][0].lower()!=TRANSFER or len(l.get('data',''))!=66: continue
                    asset=addr(l['address']); ds=store.rows('SELECT decimals FROM assets WHERE job_id=? AND address=?',(job,asset)); d=ds[0]['decimals'] if ds else next((e['decimals'] for e in es if e['asset']==asset),None)
                    idx=int(l['logIndex'],16); f='0x'+l['topics'][1][-40:].lower(); to='0x'+l['topics'][2][-40:].lower()
                    store.event(job,{'id':f'{tx}:log:{idx}:{asset}','tx_hash':tx,'block_number':int(r['blockNumber'],16),'block_hash':r.get('blockHash'),'tx_index':int(r.get('transactionIndex','0x0'),16),'log_index':idx,'timestamp':stamp,'from_address':f,'to_address':to,'asset':asset,'amount_raw':str(int(l['data'],16)),'decimals':d,'kind':'mint' if f==ZERO else 'burn' if to in (ZERO,DEAD) else 'transfer','raw_id':r['_raw_id']})
            receipts[tx]=r
        es=store.events(job); sales=detect_sales(token,es,receipts)
        pools,controls,enrichment_warnings=enrich(c,token,meta,es,sales);warnings.extend(enrichment_warnings)
        for pool,data in pools.items():kinds[pool]='dex_pool';labels[pool]=data
        for sale in sales:
            if verify_swap_deltas(sale,es,receipts[sale['tx_hash']],pools):
                sale['confidence']='STRONG EVIDENCE';sale['label']='Factory-verified v3 swap with receipt-matched pool deltas'
        assets=list(dict.fromkeys(p['asset'] for sale in sales for p in sale['proceeds'] if p['amount'] is None))[:8]
        for asset in assets:
            if c.calls>=c.budget-15:break
            dec=optional('Counterasset decimals '+asset,lambda:uint(c.rpc('eth_call',[{'to':asset,'data':'0x313ce567'},hex(meta['snapshot_block'])])))
            if dec is not None and 0<=dec<=255:
                store.execute('UPDATE events SET decimals=? WHERE job_id=? AND asset=? AND decimals IS NULL',(dec,job,asset))
                for sale in sales:
                    for p in sale['proceeds']:
                        if p['asset']==asset:p['amount']=units(p['amount_raw'],dec)
        es=store.events(job)
        valuation=optional('Historical valuation',lambda:value_sales(c,sales,pools),{'available':False,'total_usd':None,'reason':'Historical provider unavailable'})

        stage('5 / 8 · Building operational relationship candidates')
        # Avoid quadratic enumeration across every indexed holder: priority analysis only.
        links,clusters,first=relationships(es,seen,kinds)
        stage('6 / 8 · Detecting token and proceeds convergence')
        earliest={}
        for e in es:
            if e['asset']==token and e['to_address'] in seen and int(e['amount_raw'])>0:
                earliest.setdefault(e['to_address'],e)
        token_seeds=[(w,token,e) for w,e in earliest.items() if kinds.get(w) not in INFRA]
        token_hubs,token_paths,tcut=convergence(es,token_seeds,kinds,LIMITS['path_depth'],LIMITS['paths'])
        eventmap={e['id']:e for e in es}
        proceeds_seeds=[(s['wallet'],p['asset'],eventmap[p['event_id']]) for s in sales for p in s['proceeds']]
        proceeds_hubs,proceeds_paths,pcut=convergence(es,proceeds_seeds,kinds,LIMITS['path_depth'],LIMITS['paths'])
        if tcut or pcut: warnings.append('Graph path budget reached; path results are incomplete.')
        stage('7 / 8 · Scoring evidence and checking snapshot consistency')
        coordinated=coordination(sales); checkpoints=store.rows('SELECT * FROM checkpoints WHERE job_id=?',(job,))
        tokencheck=next((x for x in checkpoints if x['resource'].startswith('/tokens/'+token+'/transfers:')),None)
        complete=bool(tokencheck and tokencheck['exhausted'] and not tokencheck['error'] and ingested is not None and not ingested[1])
        anchor=optional('Snapshot reorganization check',lambda:c.rpc('eth_getBlockByNumber',[hex(meta['snapshot_block']),False]))
        consistent=bool(anchor and anchor.get('hash')==meta['snapshot_hash'])
        if not consistent: raise SourceError('Snapshot hash changed or could not be revalidated. Results withheld; rerun investigation.')
        # Explorer is separately indexed: a matching RPC anchor does not certify every indexed event.
        warnings+=['Indexer history may lag RPC or reflect a different reorganization view; only inspected receipts were cross-checked.','Official Uniswap v3 deployments are referenced and detected simple-swap pools checked against the factory. Exchange/bridge identity coverage remains incomplete.','USD estimates require configured historical pricing and valid pre-sale candles. V4, intent execution, arbitrary aggregator routes, native-ETH swap accounting, cross-chain settlement, and full authority auditing remain unsupported.','Convergence paths show chronological reachability, not ownership or conserved attribution through mixed balances.','Absence of a finding is not evidence of absence. This is a bounded investigation, not an exhaustive chain audit.']
        hs=[]; allwallets=set(h['address'] for h in hh)|set(earliest)|{e['from_address'] for e in es if e['asset']==token}
        current={h['address']:h for h in hh}
        for w in allwallets-{ZERO,DEAD}:
            incoming=[e for e in es if e['asset']==token and e['to_address']==w]; outgoing=[e for e in es if e['asset']==token and e['from_address']==w]
            ws=[s for s in sales if s['wallet']==w]; sold=sum(int(s['amount_raw']) for s in ws); received=sum(int(e['amount_raw']) for e in incoming)
            balance=balances.get(w); latest=current.get(w,{}).get('balance_raw')
            hs.append({'address':w,'kind':kinds.get(w,'unknown'),'snapshot_balance_raw':balance,'snapshot_balance':units(balance,meta['decimals']),'indexer_latest_balance_raw':latest,'indexer_latest_balance':units(latest,meta['decimals']),'supply_pct':ratio(int(balance),int(meta['total_supply_raw'])) if balance is not None else None,'historical_maximum_balance':None,'historical_maximum_reason':'Not reconstructed; complete ordered history and non-rebasing semantics not verified','received_raw':str(received),'received':units(received,meta['decimals']),'incoming_count':len(incoming),'outgoing_count':len(outgoing),'first_observed_receipt':incoming[0]['timestamp'] if incoming else None,'last_observed_activity':max((e['timestamp'] or '' for e in incoming+outgoing),default=None),'sources':sorted({e['from_address'] for e in incoming}),'candidate_sold_raw':str(sold),'candidate_sold':units(sold,meta['decimals']),'candidate_sale_count':len(ws),'sold_pct_of_observed_receipts':ratio(sold,received),'proceeds':[p for s in ws for p in s['proceeds']],'funding':first.get(w),'related_wallets':sorted({b for r in links if w in r['wallets'] for b in r['wallets'] if b!=w}),'evidence':[e['id'] for e in incoming+outgoing]})
        for h in hs:
            h['history']=holder_history(h['address'],token,es,h['snapshot_balance_raw'],meta['decimals'],complete)
            h['holding_period']=fifo_age(h['address'],token,es,sales,h['history']['opening_balance_raw']) if h['history']['available'] else {'available':False,'reason':h['history']['reason']}
        hs.sort(key=lambda h:int(h['snapshot_balance_raw'] or h['indexer_latest_balance_raw'] or h['received_raw']),reverse=True)
        for e in es:
            e['amount']=units(e['amount_raw'],e['decimals']); e['explorer_url']=EXPLORER+'/tx/'+e['tx_hash']; e['contract']=e['asset'] if e['asset']!='native:4663' else None
        proceed_ids={i for p in proceeds_paths for i in [p['origin_evidence']]+p['event_ids']}
        report={'version':'0.2.0','chain_id':4663,'token':meta,'summary':{'candidate_sellers':len({s['wallet'] for s in sales}),'candidate_sales':len(sales),'clusters':len(clusters),'candidate_tokens_sold':units(sum(int(s['amount_raw']) for s in sales),meta['decimals']),'estimated_proceeds_usd':None,'major_finding':f'{len(clusters)} evidence-linked candidate components and {len(proceeds_hubs)} potential proceeds-consolidation addresses in the collected sample. No ownership conclusion.' if clusters or proceeds_hubs else 'No qualifying relationship or proceeds-consolidation finding in the collected sample. Coverage limits prevent an all-clear conclusion.'},'coverage':{'scope':'Bounded priority investigation','token_history_cursor_exhausted':complete,'holders_basis':'Indexer latest; priority balances independently read at snapshot','snapshot_consistent':consistent,'indexed_events':len(es),'priority_wallets_traced':len(seen),'receipts_checked':len(receipts),'request_count':c.calls,'limits':LIMITS,'fallback':fallback,'checkpoints':checkpoints},'scores':scorecard(links,sales,proceeds_hubs,coordinated,es,token,complete),'holders':hs,'sales':sales,'relationships':links,'clusters':clusters,'token_convergence':token_hubs,'proceeds_convergence':proceeds_hubs,'coordinated_events':coordinated,'token_paths':token_paths,'proceeds_paths':proceeds_paths,'graphs':{'token':graph([e for e in es if e['asset']==token],kinds),'proceeds':graph([e for e in es if e['id'] in proceed_ids],kinds),'funding':graph([e for e in es if e['asset']=='native:4663'],kinds)},'events':es,'labels':labels,'warnings':warnings,'methodology':'Heuristic v0.1, uncalibrated. Scores are evidence-strength indicators, not probabilities. POSSIBLE candidate swaps are not verified DEX trades. All displayed amounts preserve raw integer values. Identity is never inferred.'}
        report['verified_pools']=pools;report['contract_controls']=controls;report['valuation']=valuation
        report['summary']['estimated_proceeds_usd']=valuation.get('total_usd')
        report['summary']['verified_simple_swaps']=sum(sale['confidence']=='STRONG EVIDENCE' for sale in sales)
        report['attribution']=attribution_bounds([e for e in es if e['id'] in proceed_ids],{p['event_id'] for sale in sales for p in sale['proceeds']},{},set()) if proceed_ids else {'available':False,'reason':'No complete proceeds accounting inputs','events':[]}
        stage('8 / 8 · Saving report and evidence references')
        for cat,items in [('cluster',clusters),('sale',sales),('token_convergence',token_hubs),('proceeds_convergence',proceeds_hubs),('coordination',coordinated)]:
            for f in items:
                fid=cat+':'+f['id']; store.execute('INSERT OR REPLACE INTO findings VALUES(?,?,?,?,?,?)',(job,fid,cat,f.get('score'),f['confidence'],json.dumps(f)))
                for eid in f['evidence']: store.execute('INSERT OR IGNORE INTO finding_evidence VALUES(?,?,?)',(job,fid,eid))
        store.update(job,status='partial',stage='Completed · bounded coverage',report_json=json.dumps(report))
    except (Cancelled,LeaseLost):
        raise
    except Exception as e:
        store.update(job,status='failed',stage='Investigation stopped — no unsupported conclusions',error=str(e)[:800])
        # Unexpected programming errors are logged server-side rather than suppressed.
        if not isinstance(e,(SourceError,ValueError)):
            import traceback; traceback.print_exc()
