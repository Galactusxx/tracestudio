"""Operator-only administration. Passwords are prompted, never printed."""
import argparse,getpass,sqlite3,os
from .core import Store
from .hardened import create_user

def main():
 p=argparse.ArgumentParser();sp=p.add_subparsers(dest='action',required=True)
 u=sp.add_parser('create-user');u.add_argument('username')
 b=sp.add_parser('backup');b.add_argument('destination')
 a=p.parse_args();s=Store()
 if a.action=='create-user':
  password=getpass.getpass('Password (14+ characters): ')
  if password!=getpass.getpass('Confirm password: '):raise SystemExit('Passwords differ')
  create_user(s,a.username,password);print('User created.')
 elif a.action=='backup':
  if os.path.exists(a.destination):raise SystemExit('Destination already exists; choose a new backup file')
  fd=os.open(a.destination,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);os.close(fd)
  out=sqlite3.connect(a.destination)
  try:
   with s.connect() as c:c.backup(out)
  finally:out.close()
  os.chmod(a.destination,0o600);print('Consistent database backup created.')
if __name__=='__main__':main()
