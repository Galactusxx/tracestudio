"""Evidence-backed enrichment. Unknown is not replaced by inferred identity or price."""
import os,urllib.parse
from collections import defaultdict,deque
from decimal import Decimal,localcontext,InvalidOperation
from .core import *
from .sources import SourceError
from .detectors import order,seconds
V3_FACTORY='0x1f7d7550b1b028f7571e69a784071f0205fd2efa'
DEPLOYMENT_SOURCE='https://developers.uniswap.org/docs/protocols/v3/deployments/v3-robinhood-chain-deployments'
REGISTRY={V3_FACTORY:{'kind':'contract','label':'Uniswap v3 factory','source':DEPLOYMENT_SOURCE},'0xcaf681a66d020601342297493863e78c959e5cb2':{'kind':'router','label':'Uniswap SwapRouter02','source':DEPLOYMENT_SOURCE},'0x8876789976decbfcbbbe364623c63652db8c0904':{'kind':'router','label':'Uniswap Universal Router','source':DEPLOYMENT_SOURCE},'0x73991a25c818bf1f1128deaab1492d45638de0d3':{'kind':'contract','label':'Uniswap position manager','source':DEPLOYMENT_SOURCE},'0x000000000022d473030f116ddee9f6b43ac78ba3':{'kind':'contract','label':'Permit2','source':DEPLOYMENT_SOURCE}}
def selector(sig):return '0x'+keccak(sig.encode())[:8]
def abi_address(data):
    if not isinstance(data,str) or len(data)!=66 or int(data[2:26],16)!=0:raise ValueError('Malformed ABI address')
    return '0x'+data[-40:].lower()
def verify_pool(c,pool,block):
    raw=[]
    def call(to,sig,args=''):
        value=c.rpc('eth_call',[{'to':to,'data':selector(sig)+args},hex(block)]);raw.append(c.last_raw);return value
    factory=abi_address(call(pool,'factory()'))
    if factory!=V3_FACTORY:return None
    t0=abi_address(call(pool,'token0()'));t1=abi_address(call(pool,'token1()'));fee=uint(call(pool,'fee()'))
    if t0>=t1 or fee>1000000:return None
    actual=abi_address(call(factory,'getPool(address,address,uint24)',t0[2:].zfill(64)+t1[2:].zfill(64)+hex(fee)[2:].zfill(64)))
    if actual!=pool:return None
    if c.rpc('eth_getCode',[pool,hex(block)]) in ('0x','0x0',None):return None
    raw.append(c.last_raw)
    return {'address':pool,'kind':'dex_pool','protocol':'Uniswap v3','factory':factory,'token0':t0,'token1':t1,'fee':fee,'source':DEPLOYMENT_SOURCE,'verification':'Official factory membership checked at snapshot','raw_evidence':[x for x in raw if x]}

def verify_swap_deltas(sale,events,receipt,pools):
    """Receipt transfer values already validated by base detector. Independently match
    signed v3 swap deltas to pool flows, including output-before-input callbacks."""
    if receipt.get('status') not in ('0x1',1):return False
    transfers=set();transfer_topic='0x'+keccak(b'Transfer(address,address,uint256)')
    for log in receipt.get('logs',[]):
        topics=log.get('topics',[]);data=log.get('data','')
        if len(topics)!=3 or topics[0].lower()!=transfer_topic or len(data)!=66:continue
        try:transfers.add((addr(log.get('address')),int(log['logIndex'],16),abi_address(topics[1]),abi_address(topics[2]),int(data,16)))
        except (ValueError,KeyError):return False
    topic='0x'+keccak(b'Swap(address,address,int256,int256,uint160,uint128,int24)')
    es=[e for e in events if e['tx_hash']==sale['tx_hash']]
    for pool in sale['pools']:
        if pool not in pools:return False
        ds=[0,0];seen=False
        for log in receipt.get('logs',[]):
            if addr(log.get('address'))==pool and log.get('topics') and log['topics'][0].lower()==topic:
                data=log.get('data','')[2:]
                if len(data)!=320:return False
                seen=True
                for i in range(2):
                    n=int(data[i*64:(i+1)*64],16);ds[i]+=n-(1<<256) if n>=(1<<255) else n
        if not seen or not ((ds[0]>0 and ds[1]<0) or (ds[0]<0 and ds[1]>0)):return False
        for i,asset in enumerate((pools[pool]['token0'],pools[pool]['token1'])):
            relevant=[e for e in es if e['asset']==asset and pool in (e['from_address'],e['to_address'])]
            if any((e['asset'],e.get('log_index'),e['from_address'],e['to_address'],int(e['amount_raw'])) not in transfers for e in relevant):return False
            net=sum(int(e['amount_raw'])*(1 if e['to_address']==pool else -1) for e in es if e['asset']==asset and pool in (e['from_address'],e['to_address']) and e['from_address']!=e['to_address'])
            if net!=ds[i]:return False
    return True

def holder_history(wallet,token,events,snapshot_balance,decimals,complete=False):
    if snapshot_balance is None:return {'available':False,'reason':'No independently read snapshot balance'}
    es=[e for e in events if e['asset']==token and wallet in (e['from_address'],e['to_address']) and e['from_address']!=e['to_address']];es.sort(key=order)
    blocks=defaultdict(list)
    for e in es:blocks[e['block_number']].append(e)
    if any(len({e['tx_hash'] for e in group})>1 and any(e.get('tx_index') is None for e in group) for group in blocks.values()):return {'available':False,'reason':'Unknown intra-block order'}
    balance=int(snapshot_balance);peak=balance
    for e in reversed(es):
        balance+=int(e['amount_raw'])*(1 if e['from_address']==wallet else -1)
        if balance<0:return {'available':False,'reason':'Ledger does not reconcile; incomplete events or nonstandard token semantics'}
        peak=max(peak,balance)
    return {'available':True,'opening_balance_raw':str(balance),'event_reconstructed_peak_raw':str(peak),'event_reconstructed_peak':units(peak,decimals),'scope':'complete indexed history' if complete else 'collected window','is_proven_lifetime_maximum':False,'assumption':'Standard non-rebasing Transfer accounting; not independent historical balance queries','evidence':[e['id'] for e in es]}

def fifo_age(wallet,token,events,sales,opening):
    lots=deque();known=unknown=0;weighted=Decimal(0);evidence=set()
    if int(opening):lots.append([int(opening),None,None])
    sale_txs={s['tx_hash'] for s in sales if s['wallet']==wallet}
    for e in sorted(events,key=order):
        if e['asset']!=token or e['from_address']==e['to_address']:continue
        amount=int(e['amount_raw']);at=seconds(e['timestamp'])
        if e['to_address']==wallet:lots.append([amount,at,e['id']])
        if e['from_address']!=wallet:continue
        while amount and lots:
            lot=lots[0];n=min(amount,lot[0]);amount-=n;lot[0]-=n
            if e['tx_hash'] in sale_txs:
                if at is None or lot[1] is None or at<lot[1]:unknown+=n
                else:known+=n;weighted+=Decimal(str(at-lot[1]))*n;evidence.update((e['id'],lot[2]))
            if not lot[0]:lots.popleft()
        if amount:return {'available':False,'reason':'Outflow exceeds reconstructed lots'}
    with localcontext() as ctx:
        ctx.prec=100;mean=str(weighted/known) if known else None
    return {'available':True,'method':'FIFO convention; opening-window lot ages are unknown','mean_known_lot_holding_seconds':mean,'known_lot_coverage_pct':ratio(known,known+unknown),'evidence':sorted(x for x in evidence if x)}

def attribution_bounds(events,seeds,opening,complete_addresses):
    required={(e[k],e['asset']) for e in events for k in ('from_address','to_address') if e[k] not in (ZERO,DEAD)}
    missing=[k for k in required if k not in opening or k[0] not in complete_addresses]
    if missing:return {'available':False,'reason':'Independent opening balances and complete ordered per-asset ledgers required','missing_count':len(missing),'events':[]}
    blocks=defaultdict(list)
    for e in events:blocks[e['block_number']].append(e)
    if any(len({e['tx_hash'] for e in group})>1 and any(e.get('tx_index') is None for e in group) for group in blocks.values()):return {'available':False,'reason':'Unknown intra-block order','events':[]}
    balances={k:int(v) for k,v in opening.items()};low=defaultdict(int);high=defaultdict(int);rows=[]
    for e in sorted(events,key=order):
        a,b=(e['from_address'],e['asset']),(e['to_address'],e['asset']);n=int(e['amount_raw'])
        if a==b:continue
        if e['from_address'] in (ZERO,DEAD):lo=hi=0
        else:
            total=balances[a]
            if total<n:return {'available':False,'reason':'Ledger deficit','events':[]}
            lo=max(0,n-(total-low[a]));hi=min(n,high[a]);low[a]=max(0,low[a]-n);high[a]=min(high[a],total-n);balances[a]-=n
        if e['id'] in seeds:lo=hi=n
        if e['to_address'] not in (ZERO,DEAD):balances[b]=balances.get(b,0)+n;low[b]=min(balances[b],low[b]+lo);high[b]=min(balances[b],high[b]+hi)
        rows.append({'event_id':e['id'],'minimum_raw':str(lo),'maximum_raw':str(hi),'observed_raw':str(n),'asset':e['asset']})
    return {'available':True,'method':'Conservative marginal bounds under arbitrary mixing; bounds across alternative paths are not additive','events':rows}

def candle_quote(payload,asset,at):
    if at is None:return None
    meta=payload.get('meta',{})
    if asset not in {addr(meta.get('base',{}).get('address')),addr(meta.get('quote',{}).get('address'))}:return None
    candidates=[]
    for row in payload.get('data',{}).get('attributes',{}).get('ohlcv_list',[]):
        if not isinstance(row,list) or len(row)<6:continue
        try:
            stamp=int(row[0]);op,hi,lo,cl,vol=map(lambda v:Decimal(str(v)),row[1:6])
            if not all(v.is_finite() for v in (op,hi,lo,cl,vol)):continue
            if 0<lo<=op<=hi and lo<=cl<=hi and vol>0 and stamp+60<=at<=stamp+360:candidates.append((stamp,cl,lo,hi))
        except (ValueError,InvalidOperation):continue
    if not candidates:return None
    stamp,close,lo,hi=max(candidates)
    return {'price_usd':str(close),'low_usd':str(lo),'high_usd':str(hi),'candle_start':stamp,'candle_end':stamp+60,'method':'Previous fully closed minute candle; indicative estimate, not execution price','source':'https://docs.coingecko.com/reference/pool-ohlcv-contract-address'}

def enrich(c,token,meta,events,sales):
    pools={};warnings=[]
    for pool in list(dict.fromkeys(a for s in sales for a in s['pools']))[:6]:
        if c.calls>=c.budget-20:break
        try:
            p=verify_pool(c,pool,meta['snapshot_block'])
            if p:pools[pool]=p
        except (SourceError,ValueError):warnings.append('Factory membership could not be verified for '+pool)
    controls=[]
    if c.calls<c.budget-15:
        try:
            v=abi_address(c.rpc('eth_call',[{'to':token,'data':selector('owner()')},hex(meta['snapshot_block'])]));controls.append({'field':'owner','value':v,'raw_id':c.last_raw,'basis':'Contract-reported owner; not verified identity or full access-control audit'})
        except (SourceError,ValueError):pass
    return pools,controls,warnings

def value_sales(c,sales,pools):
    key=os.environ.get('COINGECKO_PRO_API_KEY');priced=0;total=Decimal(0)
    if not key:return {'available':False,'total_usd':None,'reason':'Historical pricing provider not configured by operator'}
    for sale in sales:
        if c.calls>=c.budget-10:break
        at=seconds(sale['timestamp']);values=[]
        for p in sale['proceeds']:
            pool=next((a for a in sale['pools'] if a in pools and p['asset'] in (pools[a]['token0'],pools[a]['token1'])),None)
            if not pool or at is None or p.get('amount') is None:continue
            q={'aggregate':'1','before_timestamp':int(at),'limit':'10','currency':'usd','token':p['asset'],'include_empty_intervals':'false'}
            url='https://pro-api.coingecko.com/api/v3/onchain/networks/robinhood/pools/'+pool+'/ohlcv/minute?'+urllib.parse.urlencode(q)
            try:
                data=c.request(url,ref='historical_usd:'+pool+':'+p['asset']+':'+str(int(at)),headers={'x-cg-pro-api-key':key},source='coingecko');quote=candle_quote(data,p['asset'],at)
                if not quote:continue
                quote['raw_id']=c.last_raw
                with localcontext() as ctx:ctx.prec=340;value=Decimal(p['amount'])*Decimal(quote['price_usd'])
                quote['estimated_usd']=str(value);p['valuation']=quote;values.append(value)
            except (SourceError,ValueError,InvalidOperation):continue
        if values and len(values)==len(sale['proceeds']):sale['usd']=str(sum(values));priced+=1;total+=sum(values)
    return {'available':priced>0,'priced_sales':priced,'total_sales':len(sales),'priced_subset_usd':str(total) if priced else None,'total_usd':str(total) if sales and priced==len(sales) else None,'reason':'No full total without complete pricing coverage; stale or post-sale candles rejected'}
