"""Exact quantities, EIP-55 validation, durable evidence store. No dependencies."""
import json, os, re, sqlite3, hashlib, uuid, time
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import Decimal, localcontext
ROOT = Path(__file__).resolve().parent.parent
CHAIN_ID = 4663
ZERO = '0x' + '0'*40
DEAD = '0x' + '0'*36 + 'dead'
EXPLORER = 'https://robinhoodchain.blockscout.com'
MASK = (1<<64)-1
RC = [0x1,0x8082,0x800000000000808a,0x8000000080008000,0x808b,0x80000001,0x8000000080008081,0x8000000000008009,0x8a,0x88,0x80008009,0x8000000a,0x8000808b,0x800000000000008b,0x8000000000008089,0x8000000000008003,0x8000000000008002,0x8000000000000080,0x800a,0x800000008000000a,0x8000000080008081,0x8000000000008080,0x80000001,0x8000000080008008]
ROT = [[0,36,3,41,18],[1,44,10,45,2],[62,6,43,15,61],[28,55,25,21,56],[27,20,39,8,14]]
def keccak(data):
    a=[0]*25; data=bytearray(data); data.append(1)
    while len(data)%136 !=135: data.append(0)
    data.append(128)
    rol=lambda v,n: ((v<<n)|(v>>(64-n)))&MASK if n else v
    for off in range(0,len(data),136):
        for i in range(17): a[i]^=int.from_bytes(data[off+i*8:off+i*8+8],'little')
        for rc in RC:
            c=[a[x]^a[x+5]^a[x+10]^a[x+15]^a[x+20] for x in range(5)]
            d=[c[(x-1)%5]^rol(c[(x+1)%5],1) for x in range(5)]
            for x in range(5):
                for y in range(5): a[x+5*y]^=d[x]
            b=[0]*25
            for x in range(5):
                for y in range(5): b[y+5*((2*x+3*y)%5)]=rol(a[x+5*y],ROT[x][y])
            for x in range(5):
                for y in range(5): a[x+5*y]=b[x+5*y]^((~b[(x+1)%5+5*y])&b[(x+2)%5+5*y])
            a[0]^=rc
    return b''.join(x.to_bytes(8,'little') for x in a)[:32].hex()
def address(value):
    if not isinstance(value,str) or not re.fullmatch(r'0x[0-9a-fA-F]{40}',value.strip()):
        raise ValueError('Paste a complete 42-character EVM contract address.')
    value=value.strip(); s=value[2:]
    if s!=s.lower() and s!=s.upper():
        h=keccak(s.lower().encode())
        expected=''.join(c.upper() if int(h[i],16)>=8 else c for i,c in enumerate(s.lower()))
        if s!=expected: raise ValueError('Invalid EIP-55 checksum. Check the pasted address.')
    if value.lower() in (ZERO,DEAD): raise ValueError('A burn address is not a token contract.')
    return value.lower()
def addr(x):
    if isinstance(x,dict): x=x.get('hash') or x.get('address_hash')
    return x.lower() if isinstance(x,str) else None
def now(): return datetime.now(timezone.utc).isoformat()
def units(raw,decimals):
    if raw is None or decimals is None: return None
    with localcontext() as c:
        c.prec=340
        return format(Decimal(str(raw))/(Decimal(10)**int(decimals)),'f')
def ratio(a,b):
    if not b: return None
    with localcontext() as c:
        c.prec=100
        return str((Decimal(a)*100/Decimal(b)).quantize(Decimal('0.000001')))
def uint(h):
    if not isinstance(h,str) or not re.fullmatch(r'0x[0-9a-fA-F]{64}',h): raise ValueError('Malformed ABI uint256 response')
    return int(h,16)
def abi_text(h):
    b=bytes.fromhex(h.removeprefix('0x'))
    if len(b)==32: return b.rstrip(b'\0').decode('utf-8',errors='replace')
    offset=int.from_bytes(b[:32],'big')
    if offset+32>len(b): raise ValueError('Malformed ABI string')
    n=int.from_bytes(b[offset:offset+32],'big')
    if n>4096 or offset+32+n>len(b): raise ValueError('Malformed ABI string length')
    return b[offset+32:offset+32+n].decode('utf-8',errors='replace')
class Cancelled(Exception):pass
class LeaseLost(Exception):pass
class Store:
    def __init__(self,path=None):
        self.path=path or os.environ.get('FORENSICS_DB',str(ROOT/'data.sqlite3'))
        self.lease_job=None;self.lease_owner=None
        with self.connect() as c: c.executescript((ROOT/'schema.sql').read_text())
        from .hardened import migrate
        with self.connect() as c:migrate(c)
    @contextmanager
    def connect(self):
        c=sqlite3.connect(self.path,timeout=30); c.row_factory=sqlite3.Row
        try:
            c.execute('PRAGMA foreign_keys=ON')
            with c: yield c
        finally: c.close()
    def check_control(self):
        if not self.lease_job:return
        r=self.rows('SELECT cancel_requested,lease_owner,lease_until FROM jobs WHERE id=?',(self.lease_job,))[0]
        if r['cancel_requested']:raise Cancelled()
        if r['lease_owner']!=self.lease_owner or (r['lease_until'] or 0)<time.time():raise LeaseLost()
    def execute(self,sql,args=()):
        with self.connect() as c:
            if self.lease_job:
                c.execute('BEGIN IMMEDIATE')
                r=c.execute('SELECT cancel_requested,lease_owner,lease_until FROM jobs WHERE id=?',(self.lease_job,)).fetchone()
                if r['cancel_requested']:raise Cancelled()
                if r['lease_owner']!=self.lease_owner or (r['lease_until'] or 0)<time.time():raise LeaseLost()
            c.execute(sql,args)
    def rows(self,sql,args=()):
        with self.connect() as c: return [dict(r) for r in c.execute(sql,args)]
    def create_job(self,token):
        j=uuid.uuid4().hex
        self.execute('INSERT INTO jobs(id,token,chain_id,status,stage,created_at,updated_at) VALUES(?,?,4663,?,?,?,?)',(j,token,'queued','Queued',now(),now()))
        return j
    def update(self,j,**fields):
        allowed={'status','stage','snapshot_block','snapshot_hash','report_json','error'}
        assert set(fields)<=allowed
        fields['updated_at']=now()
        self.execute('UPDATE jobs SET '+','.join(k+'=?' for k in fields)+' WHERE id=?',(*fields.values(),j))
    def job(self,j):
        r=self.rows('SELECT * FROM jobs WHERE id=?',(j,))
        if not r: return None
        r=r[0]; r['report']=json.loads(r.pop('report_json')) if r['report_json'] else None
        return r
    def raw(self,j,source,ref,payload):
        body=json.dumps(payload,sort_keys=True,separators=(',',':'))
        rid=hashlib.sha256((j+source+ref+body).encode()).hexdigest()
        self.execute('INSERT OR IGNORE INTO raw_responses VALUES(?,?,?,?,?,?)',(rid,j,source,ref,now(),body)); return rid
    def event(self,j,e):
        cols=['id','tx_hash','block_number','block_hash','tx_index','log_index','trace_id','timestamp','from_address','to_address','asset','amount_raw','decimals','kind','raw_id']
        if not e.get('from_address') or not e.get('to_address') or int(e['amount_raw'])<0: return
        self.execute('INSERT OR IGNORE INTO events(job_id,chain_id,'+','.join(cols)+') VALUES('+','.join('?' for _ in range(17))+')',(j,4663,*(e.get(k) for k in cols)))
    def events(self,j): return self.rows('SELECT * FROM events WHERE job_id=? ORDER BY block_number,COALESCE(tx_index,0),COALESCE(log_index,0),id',(j,))
