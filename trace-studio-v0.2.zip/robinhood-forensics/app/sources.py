"""Bounded Robinhood RPC + Blockscout adapters. All successful responses retained."""
import json, os, time, urllib.request, urllib.parse, urllib.error
from datetime import datetime, timezone
from .core import *
TRANSFER='0x'+keccak(b'Transfer(address,address,uint256)')
SWAPS={'0x'+keccak(s.encode()) for s in ['Swap(address,uint256,uint256,uint256,uint256,address)','Swap(address,address,int256,int256,uint160,uint128,int24)']}
class SourceError(Exception): pass
class BudgetExceeded(SourceError): pass
class Client:
    def __init__(self,store,job,budget=300):
        self.store=store; self.job=job; self.calls=0; self.budget=budget; self.last=0
        self.rpc_url=os.environ.get('ROBINHOOD_RPC','https://rpc.mainnet.chain.robinhood.com')
        self.key=os.environ.get('BLOCKSCOUT_API_KEY','')
        self.base='https://api.blockscout.com/4663/api/v2' if self.key else EXPLORER+'/api/v2'
        self.last_raw=None
    def request(self,url,body=None,ref=None,headers=None,source=None):
        # URLs originate only in application configuration, never from submitted addresses/cursors.
        for attempt in range(3):
            self.store.check_control()
            if self.calls>=self.budget: raise BudgetExceeded('Investigation request budget reached')
            time.sleep(max(0,.25-(time.monotonic()-self.last)))
            self.last=time.monotonic(); self.calls+=1
            req=urllib.request.Request(url,data=json.dumps(body).encode() if body is not None else None,headers={'Content-Type':'application/json','Accept':'application/json','User-Agent':'RobinhoodForensics/0.2',**(headers or {})})
            try:
                with urllib.request.urlopen(req,timeout=12) as r:
                    data=r.read(16_000_001)
                    if len(data)>16_000_000: raise SourceError('Source response exceeded safety limit')
                    payload=json.loads(data)
                self.last_raw=self.store.raw(self.job,source or ('rpc' if body else 'blockscout'),ref or url.split('?')[0],payload)
                return payload
            except urllib.error.HTTPError as e:
                if e.code in (429,500,502,503,504) and attempt<2:
                    time.sleep(min(4,2**attempt)); continue
                raise SourceError(f'Source returned HTTP {e.code}; data unavailable') from e
            except (urllib.error.URLError,TimeoutError,OSError,json.JSONDecodeError) as e:
                if attempt<2: time.sleep(2**attempt); continue
                raise SourceError('Cannot reach or decode data source; check server network access') from e
    def rpc(self,method,params):
        p=self.request(self.rpc_url,{'jsonrpc':'2.0','id':1,'method':method,'params':params},method+':'+json.dumps(params))
        if p.get('error'): raise SourceError(f'RPC {method}: {str(p["error"].get("message","error"))[:200]}')
        if 'result' not in p: raise SourceError('Malformed RPC response')
        return p['result']
    def get(self,path,params=None):
        q=dict(params or {})
        if self.key: q['apikey']=self.key
        return self.request(self.base+path+('?' +urllib.parse.urlencode(q) if q else ''),ref=path+':'+json.dumps(params or {},sort_keys=True))
    def pages(self,path,params=None,max_pages=5):
        q=dict(params or {});resource=path+':'+json.dumps(q,sort_keys=True);exhausted=False;count=0;err=None;seen=set()
        try:
            while count<max_pages:
                self.store.check_control();fingerprint=json.dumps(q,sort_keys=True)
                if fingerprint in seen:raise SourceError('Repeated indexer cursor; completeness unknown')
                seen.add(fingerprint)
                cached=self.store.rows('SELECT raw_responses.id,payload_json FROM page_cache JOIN raw_responses ON raw_responses.id=page_cache.raw_id WHERE page_cache.job_id=? AND resource=? AND page=?',(self.job,resource,count+1))
                if cached:data=json.loads(cached[0]['payload_json']);rid=cached[0]['id']
                else:data=self.get(path,q);rid=self.last_raw
                if not isinstance(data,dict) or not isinstance(data.get('items'),list):raise SourceError('Unexpected Blockscout pagination schema')
                cursor=data.get('next_page_params')
                if cursor and not isinstance(cursor,dict):raise SourceError('Invalid cursor')
                count+=1;exhausted=not cursor
                self.store.execute('INSERT OR IGNORE INTO page_cache VALUES(?,?,?,?)',(self.job,resource,count,rid))
                yield data['items'],rid
                self.store.execute('INSERT OR REPLACE INTO checkpoints VALUES(?,?,?,?,?,?)',(self.job,resource,json.dumps(cursor),count,int(exhausted),None))
                if exhausted:break
                q={**(params or {}),**cursor}
        except (SourceError,ValueError) as e:err=str(e);raise
        finally:self.store.execute('INSERT OR REPLACE INTO checkpoints VALUES(?,?,?,?,?,?)',(self.job,resource,json.dumps(None if exhausted else q),count,int(exhausted),err))

def discover(c,token):
    actual=int(c.rpc('eth_chainId',[]),16)
    if actual!=CHAIN_ID: raise SourceError(f'Wrong network: expected 4663, received {actual}. Investigation blocked.')
    previous=c.store.job(c.job)
    if previous.get('snapshot_block') is not None:
        anchor=c.rpc('eth_getBlockByNumber',[hex(previous['snapshot_block']),False])
        if not anchor or anchor.get('hash')!=previous['snapshot_hash']:raise SourceError('Original snapshot changed; cannot resume')
        finality='Resumed original pinned snapshot; original finality is in raw block evidence'
    else:
        try:
            anchor=c.rpc('eth_getBlockByNumber',['finalized',False])
            if not anchor:raise SourceError('Finalized block unavailable')
            finality='finalized'
        except SourceError:
            height=int(c.rpc('eth_blockNumber',[]),16)
            anchor=c.rpc('eth_getBlockByNumber',[hex(max(0,height-64)),False]);finality='64-block buffer; not guaranteed finalized'
    if not anchor or not anchor.get('hash'): raise SourceError('Could not anchor investigation to a block')
    block=int(anchor['number'],16); tag=hex(block)
    c.store.update(c.job,snapshot_block=block,snapshot_hash=anchor['hash'])
    code=c.rpc('eth_getCode',[token,tag])
    if not code or code in ('0x','0x0'): raise ValueError('No deployed contract at this address on Robinhood Chain at the snapshot block.')
    call=lambda data:c.rpc('eth_call',[{'to':token,'data':data},tag])
    # ERC-20 has no universal introspection identifier: probe read methods and exclude ERC-721.
    nft=False
    try: nft=uint(call('0x01ffc9a780ac58cd'+'0'*56))==1
    except (SourceError,ValueError): pass
    if nft: raise ValueError('Contract reports ERC-721 support; not accepted as an ERC-20.')
    supply=uint(call('0x18160ddd'))
    uint(call('0x70a08231'+'0'*64))
    uint(call('0xdd62ed3e'+'0'*128))
    warnings=[]; d=None; name=None; symbol=None
    try:
        d=uint(call('0x313ce567'))
        if d>255: raise ValueError('Invalid decimals')
    except (SourceError,ValueError): warnings.append('Decimals unavailable; amounts remain raw integer units.'); d=None
    for field,selector in [('name','0x06fdde03'),('symbol','0x95d89b41')]:
        try:
            text=abi_text(call(selector))
            if field=='name': name=text
            else: symbol=text
        except (SourceError,ValueError): warnings.append(field+' unavailable')
    c.store.execute('INSERT OR REPLACE INTO assets VALUES(?,?,?,?,?,?,?)',(c.job,token,symbol,name,d,str(supply),c.last_raw))
    return {'address':token,'name':name,'symbol':symbol,'decimals':d,'total_supply_raw':str(supply),'total_supply':units(supply,d),'snapshot_block':block,'snapshot_hash':anchor['hash'],'snapshot_timestamp':datetime.fromtimestamp(int(anchor['timestamp'],16),timezone.utc).isoformat(),'finality':finality,'erc20_assessment':'ERC-20-compatible read methods; behavioral conformance is not certified','warnings':warnings,'deployer':None,'creation_transaction':None,'holder_count':None}

def normalize_transfer(t,raw_id,snapshot):
    token=t.get('token') or {}
    if token.get('type') not in (None,'ERC-20'): return None
    total=t.get('total') or {}; amount=total.get('value')
    block=t.get('block_number'); tx=t.get('transaction_hash'); idx=t.get('log_index')
    if block is None or tx is None or idx is None or amount is None: return None
    if int(block)>snapshot: return None
    asset=addr(token.get('address_hash') or token.get('address'))
    f=addr(t.get('from')); to=addr(t.get('to'))
    if not asset or not f or not to: return None
    d=total.get('decimals',token.get('decimals'))
    return {'id':f'{tx.lower()}:log:{idx}:{asset}','tx_hash':tx.lower(),'block_number':int(block),'block_hash':t.get('block_hash'),'tx_index':t.get('transaction_index'),'log_index':int(idx),'timestamp':t.get('timestamp'),'from_address':f,'to_address':to,'asset':asset,'amount_raw':str(int(amount)),'decimals':int(d) if d is not None else None,'kind':'mint' if f==ZERO else 'burn' if to in (ZERO,DEAD) else 'transfer','raw_id':raw_id}

def normalize_native(t,raw_id,snapshot,internal=False):
    block=t.get('block_number'); value=t.get('value'); tx=t.get('transaction_hash') if internal else t.get('hash')
    if t.get('status') in ('error','failed') or t.get('error') or (internal and t.get('success') is not True): return None
    if not internal and t.get('status')!='ok': return None
    # Trace index zero commonly duplicates the outer transaction. The normal tx endpoint owns it.
    if internal and t.get('index') in (None,0,'0'): return None
    if block is None or int(block)>snapshot or value is None or int(value)<=0 or not tx: return None
    f=addr(t.get('from')); to=addr(t.get('to'))
    if not f or not to: return None
    trace=str(t.get('index')) if internal else None
    return {'id':tx.lower()+(':trace:'+trace if internal else ':native'),'tx_hash':tx.lower(),'block_number':int(block),'block_hash':t.get('block_hash'),'tx_index':t.get('position') if not internal else None,'trace_id':trace,'timestamp':t.get('timestamp'),'from_address':f,'to_address':to,'asset':'native:4663','amount_raw':str(int(value)),'decimals':18,'kind':'native_transfer','raw_id':raw_id}

def ingest_transfers(c,path,snapshot,params=None,max_pages=5):
    n=0; skipped=0
    for items,rid in c.pages(path,params,max_pages):
        for t in items:
            try: e=normalize_transfer(t,rid,snapshot)
            except (TypeError,ValueError): e=None
            if e: c.store.event(c.job,e); n+=1
            else: skipped+=1
    return n,skipped

def rpc_transfer_fallback(c,token,meta,window=2048):
    """Only a bounded recent log window; never claim this is full history."""
    end=meta['snapshot_block']; start=max(0,end-window+1); stamps={}; fetched=0
    def scan(lo,hi):
        nonlocal fetched
        try: logs=c.rpc('eth_getLogs',[{'address':token,'fromBlock':hex(lo),'toBlock':hex(hi),'topics':[TRANSFER]}])
        except SourceError:
            if lo==hi: raise
            mid=(lo+hi)//2; scan(lo,mid); scan(mid+1,hi); return
        rid=c.last_raw
        if len(logs)>=1000:
            if lo==hi: raise SourceError('Single block hit log cap; complete ingestion cannot be established')
            mid=(lo+hi)//2; scan(lo,mid); scan(mid+1,hi); return
        for l in logs:
            if l.get('removed') or len(l.get('topics',[]))!=3: continue
            b=int(l['blockNumber'],16)
            if b not in stamps:
                block=c.rpc('eth_getBlockByNumber',[hex(b),False])
                stamps[b]=datetime.fromtimestamp(int(block['timestamp'],16),timezone.utc).isoformat()
            f='0x'+l['topics'][1][-40:]; to='0x'+l['topics'][2][-40:]; idx=int(l['logIndex'],16); tx=l['transactionHash'].lower()
            c.store.event(c.job,{'id':f'{tx}:log:{idx}:{token}','tx_hash':tx,'block_number':b,'block_hash':l.get('blockHash'),'tx_index':int(l['transactionIndex'],16),'log_index':idx,'timestamp':stamps[b],'from_address':f.lower(),'to_address':to.lower(),'asset':token,'amount_raw':str(int(l['data'],16)),'decimals':meta['decimals'],'kind':'mint' if f.lower()==ZERO else 'burn' if to.lower() in (ZERO,DEAD) else 'transfer','raw_id':rid}); fetched+=1
    for lo in range(start,end+1,128): scan(lo,min(lo+127,end))
    return {'from_block':start,'to_block':end,'events':fetched,'complete_history':False}
