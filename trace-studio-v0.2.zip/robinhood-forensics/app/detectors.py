"""Conservative, evidence-linked heuristics. Scores are not ownership probabilities."""
from collections import defaultdict, Counter
from itertools import combinations
from datetime import datetime
from .core import *
from .sources import SWAPS, TRANSFER
INFRA={'contract','dex_pool','exchange','bridge','router','aggregator','custodian','market_maker','multisig','airdrop','bot','mev','funding_service','burn'}
def seconds(ts):
    try: return datetime.fromisoformat(ts.replace('Z','+00:00')).timestamp()
    except (ValueError,TypeError,AttributeError): return None

def order(e): return (e['block_number'],e.get('tx_index') if e.get('tx_index') is not None else -1,e.get('log_index') if e.get('log_index') is not None else -1)
def strictly_after(a,b):
    # Missing intra-block ordering is unknown, not permission to infer temporal flow.
    if a['block_number']!=b['block_number']: return a['block_number']>b['block_number']
    if a['tx_hash']==b['tx_hash']:
        return a.get('log_index') is not None and b.get('log_index') is not None and a['log_index']>b['log_index']
    return a.get('tx_index') is not None and b.get('tx_index') is not None and a['tx_index']>b['tx_index']

def graph(events,kinds=None):
    kinds=kinds or {}; nodes=set(); edges=[]
    for e in events:
        nodes.update((e['from_address'],e['to_address']))
        edges.append({'source':e['from_address'],'target':e['to_address'],'asset':e['asset'],'event_id':e['id'],'kind':e['kind']})
    return {'nodes':[{'id':a,'kind':kinds.get(a,'burn' if a in (ZERO,DEAD) else 'unknown')} for a in sorted(nodes)],'edges':edges}

def funding(events,wallets,kinds):
    candidates=defaultdict(list)
    for e in events:
        if e['asset']=='native:4663' and e['to_address'] in wallets and int(e['amount_raw'])>0:
            candidates[e['to_address']].append(e)
    # This is earliest IN THE COLLECTED WINDOW, never a claim about lifetime first funding.
    return {w:min(es,key=order) for w,es in candidates.items()}

def relationships(events,wallets,kinds):
    wallets=sorted(set(wallets)-{ZERO,DEAD}); first=funding(events,wallets,kinds)
    out=defaultdict(set); pair_events=defaultdict(list); target_events=defaultdict(list)
    for e in events:
        if int(e['amount_raw'])<=0: continue
        out[e['from_address']].add(e['to_address'])
        pair_events[tuple(sorted((e['from_address'],e['to_address'])))].append(e)
        target_events[(e['from_address'],e['to_address'])].append(e)
    infrastructure=lambda a: kinds.get(a) in INFRA or len(out[a])>=5 or a in (ZERO,DEAD)
    links=[]
    for a,b in combinations(wallets,2):
        if infrastructure(a) or infrastructure(b): continue
        signals=[]; ids=set(); families=set(); score=0
        fa,fb=first.get(a),first.get(b)
        if fa and fb and fa['from_address']==fb['from_address'] and not infrastructure(fa['from_address']):
            signals.append({'signal':'Shared earliest observed ETH funder (not necessarily initial lifetime funding)','points':25,'family':'funding'})
            score+=25; families.add('funding'); ids.update((fa['id'],fb['id']))
            ta,tb=seconds(fa['timestamp']),seconds(fb['timestamp'])
            if ta is not None and tb is not None and abs(ta-tb)<=600:
                signals.append({'signal':'Funding within 10 minutes','points':10,'family':'funding'}); score+=10
        repeated=pair_events.get((a,b),[])
        if len({e['tx_hash'] for e in repeated})>=3:
            signals.append({'signal':'At least three direct transfer transactions','points':25,'family':'transfers'}); score+=25; families.add('transfers'); ids.update(e['id'] for e in repeated)
        shared=[x for x in out[a]&out[b] if not infrastructure(x) and x not in (a,b)]
        recurrent=[x for x in shared if len({e['tx_hash'] for e in target_events[(a,x)]})>=2 and len({e['tx_hash'] for e in target_events[(b,x)]})>=2]
        if recurrent:
            signals.append({'signal':'Repeated common non-infrastructure destinations','points':30,'family':'convergence'}); score+=30; families.add('convergence')
            ids.update(e['id'] for x in recurrent for w in (a,b) for e in target_events[(w,x)])
        # Counterparty similarity is descriptive only; no ownership points for a shared router.
        union=out[a]|out[b]; jac=len(out[a]&out[b])/len(union) if union else 0
        if score>=50 and len(families)>=2:
            links.append({'wallets':[a,b],'score':min(90,score),'confidence':'STRONG EVIDENCE' if score>=75 else 'POSSIBLE','label':'Strong evidence of operational relationship' if score>=75 else 'Potentially related','signals':signals,'evidence':sorted(ids),'counterparty_jaccard':round(jac,3),'caveat':'Heuristic operational relationship, not common ownership or identity.'})
    # Connected components are candidates; transitive membership is not all-pairs evidence.
    adj=defaultdict(set)
    for r in links:
        a,b=r['wallets']; adj[a].add(b); adj[b].add(a)
    seen=set(); clusters=[]
    for root in sorted(adj):
        if root in seen: continue
        todo=[root]; comp=set()
        while todo:
            w=todo.pop()
            if w in comp: continue
            comp.add(w); seen.add(w); todo.extend(adj[w]-comp)
        rs=[r for r in links if set(r['wallets'])<=comp]
        clusters.append({'id':f'cluster-{len(clusters)+1}','wallets':sorted(comp),'score':min(r['score'] for r in rs),'confidence':'POSSIBLE','label':'Evidence-linked component; not an ownership group','relationships':rs,'evidence':sorted(set(i for r in rs for i in r['evidence']))})
    return links,clusters,first

def detect_sales(token,events,receipts):
    """Only simple v2/v3-shaped swap transactions with an observed counterasset return.
    Unknown aggregators, spoofed events, LP changes, native receipts and ambiguous routes
    are NOT promoted to confirmed sales. Event signatures alone do not verify a DEX.
    """
    bytx=defaultdict(list)
    for e in events: bytx[e['tx_hash']].append(e)
    result=[]
    for tx,receipt in receipts.items():
        if receipt.get('status')!='0x1': continue
        logs=receipt.get('logs') or []; pools={addr(l.get('address')) for l in logs if l.get('topics') and l['topics'][0].lower() in SWAPS}
        if not pools: continue
        es=bytx[tx]; sender=addr(receipt.get('from'))
        if not sender: continue
        outgoing=[e for e in es if e['asset']==token and e['from_address']==sender and e['to_address'] in pools and int(e['amount_raw'])>0]
        if not outgoing: continue
        if any(e['asset']==token and e['to_address']==sender and int(e['amount_raw'])>0 for e in es): continue
        sold=sum(int(e['amount_raw']) for e in outgoing); usedpools={e['to_address'] for e in outgoing}
        received=[e for e in es if e['asset']!=token and e['asset']!='native:4663' and e['from_address'] in usedpools and e['to_address']==sender and int(e['amount_raw'])>0]
        if not received: continue
        if any(e['asset']!=token and e['from_address']==sender and int(e['amount_raw'])>0 for e in es): continue
        # Require all used evidence transfers to exist in the successful RPC receipt.
        def in_receipt(e):
            return any(l.get('topics') and l['topics'][0].lower()==TRANSFER and len(l['topics'])==3 and addr(l.get('address'))==e['asset'] and int(l.get('logIndex','-0x1'),16)==e['log_index'] and '0x'+l['topics'][1][-40:].lower()==e['from_address'] and '0x'+l['topics'][2][-40:].lower()==e['to_address'] and int(l.get('data','0x0'),16)==int(e['amount_raw']) for l in logs)
        if not all(in_receipt(e) for e in outgoing+received): continue
        result.append({'id':'sale-'+tx,'wallet':sender,'tx_hash':tx,'timestamp':outgoing[0]['timestamp'],'block_number':outgoing[0]['block_number'],'amount_raw':str(sold),'amount':units(sold,outgoing[0]['decimals']),'pools':sorted(usedpools),'proceeds':[{'asset':e['asset'],'amount_raw':e['amount_raw'],'amount':units(e['amount_raw'],e['decimals']),'event_id':e['id']} for e in received],'usd':None,'confidence':'POSSIBLE','label':'Swap-backed candidate sale; pool identity unverified','evidence':[e['id'] for e in outgoing+received],'receipt_raw_id':receipt.get('_raw_id')})
    return result

def convergence(events,seeds,kinds,max_depth=4,max_paths=3000):
    """Chronological same-asset reachability, NOT fungible-coin attribution.
    seeds: (wallet, asset, origin_event). The origin event is retained as evidence.
    Infrastructure is a terminal endpoint, never an ownership/consolidation hub.
    """
    out=defaultdict(list)
    for e in events:
        if int(e['amount_raw'])>0: out[(e['from_address'],e['asset'])].append(e)
    paths=[]; truncated=False
    for source,asset,origin in seeds:
        stack=[(source,origin,[],{source})]
        while stack:
            w,previous,path,seen=stack.pop()
            if len(path)>=max_depth: continue
            for e in out.get((w,asset),[]):
                if e['to_address'] in seen or not strictly_after(e,previous): continue
                p=path+[e]; dest=e['to_address']
                paths.append({'source':source,'destination':dest,'asset':asset,'origin_evidence':origin['id'],'event_ids':[x['id'] for x in p],'addresses':[source]+[x['to_address'] for x in p],'depth':len(p),'attribution':'Possible chronological flow; amounts are not attributed through commingled balances.'})
                if len(paths)>=max_paths: truncated=True; break
                if kinds.get(dest) not in INFRA and dest not in (ZERO,DEAD): stack.append((dest,e,p,seen|{dest}))
            if truncated: break
        if truncated: break
    grouped=defaultdict(list); eventmap={e['id']:e for e in events}
    for p in paths:
        if kinds.get(p['destination']) not in INFRA and p['destination'] not in (ZERO,DEAD): grouped[(p['destination'],p['asset'])].append(p)
    hubs=[]
    for (dest,asset),ps in grouped.items():
        sources={p['source'] for p in ps}
        if len(sources)<2: continue
        end_ids={p['event_ids'][-1] for p in ps}
        terminal=[eventmap[i] for i in end_ids]; times=[seconds(e['timestamp']) for e in terminal]; times=[t for t in times if t is not None]
        source_txs={s:{eventmap[p['event_ids'][0]]['tx_hash'] for p in ps if p['source']==s} for s in sources}
        repeat=sum(max(0,len(txs)-1) for txs in source_txs.values())
        days={e['timestamp'][:10] for e in terminal if e['timestamp']}
        score=min(85,20+min(20,len(sources)*5)+(20 if repeat else 0)+(10 if len(days)>1 else 0))
        hubs.append({'id':'hub-'+dest+'-'+asset,'address':dest,'asset':asset,'source_wallets':sorted(sources),'source_count':len(sources),'score':score,'confidence':'POSSIBLE','label':'Potential consolidation address','repeat_events':repeat,'duration_seconds':max(times)-min(times) if times else None,'observed_received_raw':str(sum(int(e['amount_raw']) for e in terminal)),'observed_received':units(sum(int(e['amount_raw']) for e in terminal),terminal[0]['decimals']),'attributable_proceeds':None,'percentage_of_proceeds':None,'paths':ps,'downstream_event_ids':[e['id'] for e in events if e['from_address']==dest and any(strictly_after(e,t) for t in terminal)],'evidence':sorted({i for p in ps for i in [p['origin_evidence']]+p['event_ids']}),'caveat':'Sum is unique terminal transfers, not source-attributed sale proceeds. Unknown service addresses can create false positives.'})
    return sorted(hubs,key=lambda h:h['score'],reverse=True),paths,truncated

def coordination(sales):
    buckets=[]; ordered=sorted([s for s in sales if seconds(s['timestamp']) is not None],key=lambda s:seconds(s['timestamp']))
    used=set()
    for s in ordered:
        if s['id'] in used: continue
        group=[x for x in ordered if 0<=seconds(x['timestamp'])-seconds(s['timestamp'])<=600 and x['id'] not in used]
        if len({x['wallet'] for x in group})<2: continue
        used.update(x['id'] for x in group)
        buckets.append({'id':'coord-'+s['tx_hash'],'wallets':sorted({x['wallet'] for x in group}),'start':s['timestamp'],'end':group[-1]['timestamp'],'score':20,'confidence':'WEAK CORRELATION','label':'Candidate sales within 10 minutes; timing alone does not establish coordination','evidence':sorted({e for x in group for e in x['evidence']})})
    membership=Counter(tuple(b['wallets']) for b in buckets)
    for b in buckets:
        if membership[tuple(b['wallets'])]>=2:
            b['score']=40; b['label']='Repeated temporal co-selling; common market response remains an alternative'
    return buckets

def scorecard(relationships_,sales,hubs,coordinated,events,token,complete):
    return {
      'wallet_relationship':{'value':max((x['score'] for x in relationships_),default=None),'reason':'Highest pair heuristic; requires at least two independent evidence families.'},
      'token_provenance':{'value':None,'reason':'Full lifetime origin, mint authority and allocation roles are not verified. Observed paths are available.'},
      'selling_coordination':{'value':max((x['score'] for x in coordinated),default=None),'reason':'Temporal co-selling; repeated windows increase score. Never establishes identity.'},
      'convergence':{'value':max((x['score'] for x in hubs),default=None),'reason':'Chronological same-asset multi-source reachability; excludes known infrastructure.'},
      'consolidation':{'value':max((x['score'] for x in hubs),default=None),'reason':'20 base + up to 20 for source count + 20 repetition + 10 multi-day persistence; capped at 85. Heuristic, not a probability.'},
      'overall_investigation':{'value':None,'reason':'No calibrated overall risk model. Coverage and evidence strength are reported separately.'}}
