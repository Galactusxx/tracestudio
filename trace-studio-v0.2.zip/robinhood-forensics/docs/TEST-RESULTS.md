# v0.2 validation record

## Passed in this environment

- 58 Python tests: discovery, ingestion, detectors, pipeline, authentication, CSRF/origin/Host checks, account isolation, secure cookie attributes, worker exclusivity, cancellation, expired-lease fencing, whole fixture pipeline through the worker, cached page replay, holder reconstruction/FIFO, attribution prerequisites, historical candle rules, factory membership, verified callback-order swaps, and spoofed transfer/delta rejection.
- Python compilation and browser JavaScript syntax checks.
- Local HTTPS browser end-to-end test: actual sign-in/session cookie, CSRF-backed submission, worker completion, authenticated raw evidence, saved case reopening, logout invalidation, themes, responsive overflow checks, and eight report tabs.
- Compose YAML and embedded healthcheck syntax validation.
- Clean archive extraction, file-hash manifest verification, required deployment-file checks, and rerun of Python tests.
- Desktop light/dark, mobile landing, and graph screenshots inspected. Browser tests exercised other report states; those are not a substitute for exhaustive accessibility or cross-browser certification.

## Test data boundary

All successful investigation tests use explicitly synthetic fixtures in isolated databases. They are NOT real Robinhood Chain findings. The shipped interface preview has no fabricated wallets, trades, prices, or conclusions.

## Blocked or unverified

- Live RPC/indexer validation failed because the source endpoints were unreachable from this sandbox. No successful live on-chain end-to-end investigation was validated.
- Production Gunicorn dependency is not installed here; package-host access is unavailable.
- Docker image build, vulnerability scans, pinned production image digests, target-host public TLS, operational backup restoration, and realistic load testing remain unverified.
- Historical CoinGecko adapter has unit-tested selection rules but no successful live provider integration test here.
- Full V4/intent/aggregator/native swap decoding, cross-chain settlement resolution, exhaustive histories, comprehensive infrastructure labels, and distributed large-scale storage are not complete.

`RELEASE-GATES.json` records the actual fail-closed release check. Passing synthetic tests must not be represented as production signoff.
